"""Abstract provider interface and shared exceptions."""
from __future__ import annotations

from abc import ABC, abstractmethod


class RateLimitError(Exception):
    """Raised when the API returns a 429 / quota-exceeded response."""


class ServerError(Exception):
    """Raised on transient 5xx errors."""


class BaseProvider(ABC):
    @abstractmethod
    def generate(
        self,
        prompt: str,
        *,
        temperature: float,
        top_p: float,
        max_tokens: int,
    ) -> tuple[str, str]:
        """Return (response_text, model_version_string)."""

    @property
    @abstractmethod
    def model_id(self) -> str:
        """The model identifier as passed by the caller."""
