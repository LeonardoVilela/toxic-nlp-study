"""Local vLLM backend for open-weight generative models.

vLLM gives 5-20x higher throughput than transformers.generate() via:
  - PagedAttention KV cache
  - Continuous batching across requests
  - Optimized CUDA kernels
  - Native tensor parallelism across multiple GPUs

Hidden-state extraction (within_model_analysis) still uses plain transformers,
because vLLM does not expose last_hidden_state. This provider only handles
the text-generation side.
"""
from __future__ import annotations

import gc
import threading

import torch

from .base import BaseProvider


# Per-alias tensor-parallel size. TP must divide the model's number of
# attention heads. Sized so each shard fits in one A10G (24 GB) with
# ~10% headroom for KV cache.
TP_SIZE: dict[str, int] = {
    "llama-3.1-8b":       1,
    "qwen3-8b":           1,
    "openai/gpt-oss-20b": 2,
    "gemma-3-27b":        4,
    "qwen3-32b":          4,
    "llama-4-scout":      4,
    "llama-4-maverick":   8,
}


def _resolve_hf_id(alias: str) -> str:
    from within_model_analysis import OPEN_WEIGHT_MODELS
    return OPEN_WEIGHT_MODELS.get(alias, alias)


def _force_4bit(alias: str) -> bool:
    from within_model_analysis import FORCE_4BIT
    return alias in FORCE_4BIT


class LocalProvider(BaseProvider):
    def __init__(self, model: str) -> None:
        from vllm import LLM  # deferred import — heavy
        self._model_id = model
        self._lock = threading.Lock()
        hf_id = _resolve_hf_id(model)
        tp = TP_SIZE.get(model, 1)

        kwargs: dict = dict(
            model=hf_id,
            tensor_parallel_size=tp,
            dtype="bfloat16",
            trust_remote_code=True,
            max_model_len=4096,
            gpu_memory_utilization=0.90,
            enforce_eager=False,
        )
        if _force_4bit(model):
            # bnb 4-bit path for models whose bf16 weights would exceed
            # total VRAM (Llama-4 Scout/Maverick).
            kwargs["quantization"] = "bitsandbytes"
            kwargs["load_format"] = "bitsandbytes"

        self._llm = LLM(**kwargs)

    @property
    def model_id(self) -> str:
        return self._model_id

    def generate(
        self,
        prompt: str,
        *,
        temperature: float,
        top_p: float,
        max_tokens: int,
    ) -> tuple[str, str]:
        texts, version = self.generate_batch(
            [prompt],
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
        )
        return texts[0], version

    def generate_batch(
        self,
        prompts: list[str],
        *,
        temperature: float,
        top_p: float,
        max_tokens: int,
    ) -> tuple[list[str], str]:
        from vllm import SamplingParams
        sp = SamplingParams(
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
        )
        conversations = [[{"role": "user", "content": p}] for p in prompts]
        with self._lock:
            outputs = self._llm.chat(conversations, sampling_params=sp)
        texts = [o.outputs[0].text for o in outputs]
        return texts, self._model_id

    def close(self) -> None:
        """Release GPU memory — call before loading another large model
        (e.g. before within_model_analysis loads the same model under
        transformers for hidden-state extraction)."""
        if getattr(self, "_llm", None) is None:
            return
        try:
            from vllm.distributed.parallel_state import (
                destroy_distributed_environment,
                destroy_model_parallel,
            )
            destroy_model_parallel()
            destroy_distributed_environment()
        except Exception:
            pass
        del self._llm
        self._llm = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
