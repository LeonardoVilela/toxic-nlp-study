"""OpenAI (GPT) provider.

Parameter rules by model family:
  gpt-4o / gpt-4o-mini  : temperature, top_p, max_tokens (old API)
  gpt-4.1 / gpt-5       : temperature, max_completion_tokens (no top_p, no reasoning_effort)
  o1 / o3 / o4          : max_completion_tokens only (no temperature, no top_p)
"""
from __future__ import annotations

import openai

from .base import BaseProvider, RateLimitError, ServerError

_NEW_MODELS   = ("gpt-4.1", "gpt-5")           # temperature + max_completion_tokens
_O_SERIES     = ("o1", "o3", "o4")              # max_completion_tokens only


class OpenAIProvider(BaseProvider):
    def __init__(self, model: str, api_key: str) -> None:
        self._model = model
        self._client = openai.OpenAI(api_key=api_key)

    @property
    def model_id(self) -> str:
        return self._model

    def generate(
        self,
        prompt: str,
        *,
        temperature: float,
        top_p: float,
        max_tokens: int,
    ) -> tuple[str, str]:
        try:
            kwargs: dict = dict(
                model=self._model,
                messages=[{"role": "user", "content": prompt}],
            )

            if any(self._model.startswith(p) for p in _O_SERIES):
                # Reasoning models: only token limit, no sampling params
                kwargs["max_completion_tokens"] = max_tokens

            elif any(self._model.startswith(p) for p in _NEW_MODELS):
                # gpt-4.1 / gpt-5: temperature yes, top_p not recommended,
                # no reasoning_effort → standard (non-reasoning) mode
                kwargs["max_completion_tokens"] = max_tokens
                kwargs["temperature"] = temperature

            else:
                # Legacy models (gpt-4o, gpt-4o-mini, …)
                kwargs["max_tokens"] = max_tokens
                kwargs["temperature"] = temperature
                kwargs["top_p"] = top_p

            resp = self._client.chat.completions.create(**kwargs)
            text = resp.choices[0].message.content or ""
            version = resp.model
            return text, version
        except openai.RateLimitError as e:
            raise RateLimitError(str(e)) from e
        except openai.APIStatusError as e:
            if e.status_code >= 500:
                raise ServerError(str(e)) from e
            raise
