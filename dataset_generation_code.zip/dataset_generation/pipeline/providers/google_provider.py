"""Google (Gemini) provider."""
from __future__ import annotations

from google import genai
from google.genai import types

from .base import BaseProvider, RateLimitError, ServerError


class GoogleProvider(BaseProvider):
    def __init__(self, model: str, api_key: str) -> None:
        self._model = model
        self._client = genai.Client(api_key=api_key)

    @property
    def model_id(self) -> str:
        return self._model

    def generate(
        self,
        prompt: str,
        *,
        temperature: float,
        top_p: float,
        max_tokens: int,
    ) -> tuple[str, str]:
        try:
            config = types.GenerateContentConfig(
                temperature=temperature,
                top_p=top_p,
                max_output_tokens=max_tokens,
            )
            resp = self._client.models.generate_content(
                model=self._model,
                contents=prompt,
                config=config,
            )
            text = resp.text or ""
            version = self._model
            return text, version
        except Exception as e:
            msg = str(e).lower()
            if "quota" in msg or "rate" in msg or "429" in msg:
                raise RateLimitError(str(e)) from e
            if "500" in msg or "503" in msg or "server" in msg:
                raise ServerError(str(e)) from e
            raise
