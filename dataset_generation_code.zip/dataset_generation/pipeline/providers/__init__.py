"""Provider factory — lazily imported to avoid requiring all SDKs."""
from __future__ import annotations

from .base import BaseProvider, RateLimitError, ServerError


def get_provider(model_id: str, keys: dict[str, str]) -> BaseProvider:
    if model_id.startswith("claude"):
        from .anthropic_provider import AnthropicProvider
        return AnthropicProvider(model_id, keys.get("ANTHROPIC_API_KEY", ""))
    if model_id.startswith(("gpt-", "o1-", "o3-", "o4-")):
        from .openai_provider import OpenAIProvider
        return OpenAIProvider(model_id, keys.get("OPENAI_API_KEY", ""))
    if model_id.startswith("gemini"):
        from .google_provider import GoogleProvider
        return GoogleProvider(model_id, keys.get("GEMINI_API_KEY", ""))
    from .local_provider import LocalProvider
    return LocalProvider(model_id)


__all__ = ["get_provider", "BaseProvider", "RateLimitError", "ServerError"]
