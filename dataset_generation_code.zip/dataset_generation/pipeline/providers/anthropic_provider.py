"""Anthropic (Claude) provider.

API constraint: temperature and top_p are mutually exclusive.
We use temperature only (top_p=1.0 is a no-op anyway).
"""
from __future__ import annotations

import anthropic

from .base import BaseProvider, RateLimitError, ServerError


class AnthropicProvider(BaseProvider):
    def __init__(self, model: str, api_key: str) -> None:
        self._model = model
        self._client = anthropic.Anthropic(api_key=api_key)

    @property
    def model_id(self) -> str:
        return self._model

    def generate(
        self,
        prompt: str,
        *,
        temperature: float,
        top_p: float,
        max_tokens: int,
    ) -> tuple[str, str]:
        try:
            msg = self._client.messages.create(
                model=self._model,
                max_tokens=max_tokens,
                temperature=temperature,
                # top_p intentionally omitted: Anthropic rejects both at once
                messages=[{"role": "user", "content": prompt}],
            )
            text = msg.content[0].text
            version = msg.model
            return text, version
        except anthropic.RateLimitError as e:
            raise RateLimitError(str(e)) from e
        except anthropic.APIStatusError as e:
            if e.status_code >= 500:
                raise ServerError(str(e)) from e
            raise
