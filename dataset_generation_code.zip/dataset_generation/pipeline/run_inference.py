#!/usr/bin/env python3
"""Query generative models for each prompt in the bias dataset.

Usage examples:
  # Dry-run — prints what would be called, zero API cost
  python pipeline/run_inference.py --model claude-haiku-4-5 --dry-run

  # Smoke test: 3 scenarios × 2 samples
  python pipeline/run_inference.py --model claude-haiku-4-5 --limit 3 --n-samples 2

  # Full run
  python pipeline/run_inference.py --model claude-haiku-4-5
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).parent))

import tqdm

from _common import (
    OUTPUTS_DIR,
    atomic_write_json,
    get_regime,
    is_valid_json,
    load_config,
    load_dataset,
    load_keys,
    response_path,
    setup_logging,
)
from providers import RateLimitError, ServerError, get_provider

logger = setup_logging("run_inference")


# ── Cost estimation ────────────────────────────────────────────────────────────

CHARS_PER_TOKEN = 4.0  # rough approximation


def _cost_table(cfg: dict) -> dict[str, dict[str, float]]:
    return cfg.get("cost_per_million_tokens", {})


def _estimate_cost(
    prompt: str,
    max_tokens: int,
    model: str,
    cost_table: dict[str, dict[str, float]],
) -> float:
    rates = cost_table.get(model) or cost_table.get("default", {"input": 1.0, "output": 1.0})
    in_tokens = len(prompt) / CHARS_PER_TOKEN
    out_tokens = max_tokens
    return (in_tokens * rates["input"] + out_tokens * rates["output"]) / 1_000_000


# ── Core worker ───────────────────────────────────────────────────────────────

async def _call_with_backoff(
    executor: ThreadPoolExecutor,
    provider: Any,
    prompt: str,
    temperature: float,
    top_p: float,
    max_tokens: int,
    max_retries: int,
) -> tuple[str, str]:
    loop = asyncio.get_event_loop()
    for attempt in range(max_retries):
        try:
            text, version = await loop.run_in_executor(
                executor,
                lambda p=prompt: provider.generate(
                    p, temperature=temperature, top_p=top_p, max_tokens=max_tokens
                ),
            )
            return text, version
        except RateLimitError:
            wait = 2 ** attempt
            logger.warning("Rate-limited (attempt %d/%d). Retrying in %ds.", attempt + 1, max_retries, wait)
            await asyncio.sleep(wait)
        except ServerError:
            wait = 2 ** attempt
            logger.warning("Server error (attempt %d/%d). Retrying in %ds.", attempt + 1, max_retries, wait)
            await asyncio.sleep(wait)
    raise RuntimeError(f"All {max_retries} attempts failed for a prompt.")


async def _process_one(
    *,
    scenario: dict,
    versao: dict,
    sample_idx: int,
    provider: Any,
    semaphore: asyncio.Semaphore,
    executor: ThreadPoolExecutor,
    temperature: float,
    top_p: float,
    max_tokens: int,
    max_retries: int,
    pbar: tqdm.tqdm,
    cost_acc: list[float],
    cost_table: dict,
) -> None:
    out = response_path(
        OUTPUTS_DIR,
        provider.model_id,
        scenario["scenario_id"],
        versao["grupo_racial_alvo"],
        sample_idx,
    )
    if is_valid_json(out):
        pbar.update(1)
        return
    if out.exists():
        logger.warning("Corrupt/incomplete response file — will overwrite: %s", out)

    async with semaphore:
        # Re-check inside semaphore (another coroutine may have written it)
        if is_valid_json(out):
            pbar.update(1)
            return

        prompt = versao["frase"]
        try:
            text, version = await _call_with_backoff(
                executor, provider, prompt,
                temperature, top_p, max_tokens, max_retries,
            )
        except Exception as exc:
            logger.error(
                "Failed scenario=%s group=%s sample=%d: %s: %s",
                scenario["scenario_id"], versao["grupo_racial_alvo"], sample_idx,
                type(exc).__name__, str(exc) or "(no message)",
                exc_info=True,
            )
            pbar.update(1)
            return

        record: dict[str, Any] = {
            "scenario_id": scenario["scenario_id"],
            "categoria": scenario["categoria"],
            "dimensao_vies": scenario["dimensao_vies"],
            "grupo_racial_alvo": versao["grupo_racial_alvo"],
            "frase_prompt": prompt,
            "response_text": text,
            "model": provider.model_id,
            "model_version": version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "temperature": temperature,
            "top_p": top_p,
            "max_tokens": max_tokens,
            "regime": get_regime(scenario["categoria"]),
        }
        atomic_write_json(out, record)

        cost = _estimate_cost(prompt, max_tokens, provider.model_id, cost_table)
        cost_acc[0] += cost
        pbar.set_postfix({"cost_USD": f"~${cost_acc[0]:.4f}"})
        pbar.update(1)


# ── Batched local path ────────────────────────────────────────────────────────

async def _run_batched(
    *,
    provider: Any,
    tasks: list[tuple[dict, dict, int]],
    temperature: float,
    top_p: float,
    max_tokens: int,
    batch_size: int,
    cost_acc: list[float],
    cost_table: dict,
) -> None:
    """For providers that expose generate_batch (local HF models), process
    many prompts per GPU call. Skips already-cached outputs. Runs in the
    asyncio loop's default executor (single-threaded by design — the lock
    in LocalProvider serialises anyway)."""
    pending: list[tuple[dict, dict, int, Path]] = []
    for sc, v, s in tasks:
        out = response_path(
            OUTPUTS_DIR, provider.model_id, sc["scenario_id"],
            v["grupo_racial_alvo"], s,
        )
        if is_valid_json(out):
            continue
        if out.exists():
            logger.warning("Corrupt/incomplete — will overwrite: %s", out)
        pending.append((sc, v, s, out))

    loop = asyncio.get_event_loop()
    with tqdm.tqdm(total=len(pending), desc="Inference", unit="call") as pbar:
        for i in range(0, len(pending), batch_size):
            chunk = pending[i : i + batch_size]
            prompts = [v["frase"] for _, v, _, _ in chunk]
            try:
                texts, version = await loop.run_in_executor(
                    None,
                    lambda ps=prompts: provider.generate_batch(
                        ps, temperature=temperature, top_p=top_p,
                        max_tokens=max_tokens,
                    ),
                )
            except Exception as exc:
                logger.error(
                    "Batch of %d failed: %s: %s",
                    len(chunk), type(exc).__name__, str(exc) or "(no message)",
                    exc_info=True,
                )
                pbar.update(len(chunk))
                continue

            now_iso = datetime.now(timezone.utc).isoformat()
            for (sc, v, s, out), text in zip(chunk, texts):
                record: dict[str, Any] = {
                    "scenario_id": sc["scenario_id"],
                    "categoria": sc["categoria"],
                    "dimensao_vies": sc["dimensao_vies"],
                    "grupo_racial_alvo": v["grupo_racial_alvo"],
                    "frase_prompt": v["frase"],
                    "response_text": text,
                    "model": provider.model_id,
                    "model_version": version,
                    "timestamp": now_iso,
                    "temperature": temperature,
                    "top_p": top_p,
                    "max_tokens": max_tokens,
                    "regime": get_regime(sc["categoria"]),
                }
                atomic_write_json(out, record)
                cost = _estimate_cost(
                    v["frase"], max_tokens, provider.model_id, cost_table,
                )
                cost_acc[0] += cost
            pbar.set_postfix({"cost_USD": f"~${cost_acc[0]:.4f}"})
            pbar.update(len(chunk))


# ── Main ──────────────────────────────────────────────────────────────────────

async def main(args: argparse.Namespace, cfg: dict) -> None:
    gen = cfg["generation"]
    temperature = args.temperature if args.temperature is not None else gen["temperature"]
    top_p = args.top_p if args.top_p is not None else gen["top_p"]
    max_tokens = args.max_tokens if args.max_tokens is not None else gen["max_tokens"]
    n_samples = args.n_samples if args.n_samples is not None else gen["n_samples"]
    concurrency = args.concurrency if args.concurrency is not None else gen["concurrency"]
    max_retries = gen["max_retries"]

    dataset = load_dataset()
    if args.limit:
        dataset = dataset[: args.limit]

    # Build full task list
    tasks: list[tuple[dict, dict, int]] = [
        (scenario, versao, s)
        for scenario in dataset
        for versao in scenario["versoes"]
        for s in range(n_samples)
    ]

    cost_table = _cost_table(cfg)
    total_prompts = sum(len(sc["versoes"]) * n_samples for sc in dataset)

    if args.dry_run:
        cached = sum(
            1
            for sc, v, s in tasks
            if is_valid_json(response_path(OUTPUTS_DIR, args.model, sc["scenario_id"], v["grupo_racial_alvo"], s))
        )
        pending_count = len(tasks) - cached
        # Estimate cost on a sample prompt
        sample_prompt = dataset[0]["versoes"][0]["frase"] if dataset else ""
        unit_cost = _estimate_cost(sample_prompt, max_tokens, args.model, cost_table)
        est_cost = unit_cost * pending_count
        print(f"[dry-run] Scenarios  : {len(dataset)}")
        print(f"[dry-run] Total calls: {total_prompts}  ({cached} cached, {pending_count} pending)")
        print(f"[dry-run] Est. cost  : ~${est_cost:.4f} USD (using ~{CHARS_PER_TOKEN} chars/token)")
        print(f"[dry-run] Model      : {args.model}")
        print(f"[dry-run] temperature={temperature}  top_p={top_p}  max_tokens={max_tokens}  n_samples={n_samples}")
        return

    pending_count = sum(
        1
        for sc, v, s in tasks
        if not is_valid_json(response_path(OUTPUTS_DIR, args.model, sc["scenario_id"], v["grupo_racial_alvo"], s))
    )
    if pending_count == 0:
        logger.info("All %d responses already cached for %s — skipping.", len(tasks), args.model)
        print(f"All {len(tasks)} responses already cached for {args.model}.")
        return

    keys = load_keys()
    provider = get_provider(args.model, keys)
    logger.info(
        "Starting inference: model=%s scenarios=%d n_samples=%d concurrency=%d pending=%d",
        args.model, len(dataset), n_samples, concurrency, pending_count,
    )

    cost_acc = [0.0]

    if hasattr(provider, "generate_batch"):
        batch_size = gen.get("batch_size", 16)
        await _run_batched(
            provider=provider, tasks=tasks,
            temperature=temperature, top_p=top_p, max_tokens=max_tokens,
            batch_size=batch_size, cost_acc=cost_acc, cost_table=cost_table,
        )
    else:
        semaphore = asyncio.Semaphore(concurrency)
        executor = ThreadPoolExecutor(max_workers=concurrency)
        with tqdm.tqdm(total=len(tasks), desc="Inference", unit="call") as pbar:
            coros = [
                _process_one(
                    scenario=sc, versao=v, sample_idx=s,
                    provider=provider, semaphore=semaphore, executor=executor,
                    temperature=temperature, top_p=top_p, max_tokens=max_tokens,
                    max_retries=max_retries, pbar=pbar,
                    cost_acc=cost_acc, cost_table=cost_table,
                )
                for sc, v, s in tasks
            ]
            # return_exceptions=True prevents one failed call from cancelling all others
            results = await asyncio.gather(*coros, return_exceptions=True)
            for r in results:
                if isinstance(r, Exception):
                    logger.error("Unhandled exception in worker: %s", r)

    # Release GPU memory (vLLM/local providers) so the next stage can load
    # the same model under transformers for hidden-state extraction.
    close_fn = getattr(provider, "close", None)
    if callable(close_fn):
        try:
            close_fn()
        except Exception as exc:
            logger.warning("Provider close() raised: %s", exc)

    logger.info("Done. Estimated total cost: ~$%.4f USD", cost_acc[0])
    print(f"\nEstimated total cost: ~${cost_acc[0]:.4f} USD")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Query generative models on the bias dataset.")
    parser.add_argument("--model", required=True, help="Model ID (e.g. claude-haiku-4-5, gpt-4o-mini)")
    parser.add_argument("--n-samples", type=int, default=None, help="Samples per prompt (default from config)")
    parser.add_argument("--temperature", type=float, default=None)
    parser.add_argument("--top-p", type=float, default=None)
    parser.add_argument("--max-tokens", type=int, default=None)
    parser.add_argument("--concurrency", type=int, default=None, help="Max concurrent API calls")
    parser.add_argument("--dry-run", action="store_true", help="Print plan without making API calls")
    parser.add_argument("--limit", type=int, default=None, metavar="K", help="Only process first K scenarios")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    cfg = load_config()
    asyncio.run(main(args, cfg))
