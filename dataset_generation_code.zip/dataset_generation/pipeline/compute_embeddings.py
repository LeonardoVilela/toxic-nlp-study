#!/usr/bin/env python3
"""Encode cached responses with a neutral sentence encoder.

Usage:
  python pipeline/compute_embeddings.py --encoder bge --model claude-haiku-4-5
  python pipeline/compute_embeddings.py --encoder e5  --model claude-haiku-4-5 --batch-size 16
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import numpy as np
import torch
import tqdm
from transformers import AutoModel, AutoTokenizer

from _common import (
    OUTPUTS_DIR,
    atomic_write_npy,
    embedding_path,
    is_valid_npy,
    load_config,
    setup_logging,
)

logger = setup_logging("compute_embeddings")

ENCODER_PREFIX = {
    "e5": "query: ",   # multilingual-e5 requires instruction prefix
}


def _mean_pool(token_embeddings: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
    mask = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return (token_embeddings * mask).sum(1) / mask.sum(1).clamp(min=1e-9)


def _l2_normalize(x: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(x, axis=1, keepdims=True)
    return x / np.where(norms == 0, 1.0, norms)


class Encoder:
    def __init__(self, encoder_key: str, model_name: str) -> None:
        self.key = encoder_key
        self.prefix = ENCODER_PREFIX.get(encoder_key, "")
        on_gpu = torch.cuda.is_available()
        device_str = "cuda" if on_gpu else "cpu"
        self.device = torch.device(device_str)
        dtype = torch.float16 if on_gpu else torch.float32
        if on_gpu:
            gpu_name = torch.cuda.get_device_name(0)
            vram = torch.cuda.get_device_properties(0).total_memory // (1024 ** 2)
            logger.info(
                "Loading encoder %s (%s) on %s [%s, %d MiB] dtype=%s",
                encoder_key, model_name, device_str, gpu_name, vram, dtype,
            )
        else:
            logger.warning(
                "CUDA not available — running on CPU. "
                "Install torch with CUDA support for GPU acceleration."
            )
            logger.info("Loading encoder %s (%s) on cpu", encoder_key, model_name)
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.model = AutoModel.from_pretrained(model_name, torch_dtype=dtype).to(self.device)
        self.model.eval()

    @torch.no_grad()
    def encode(self, texts: list[str]) -> np.ndarray:
        prefixed = [self.prefix + t for t in texts]
        enc = self.tokenizer(
            prefixed,
            padding=True,
            truncation=True,
            max_length=512,
            return_tensors="pt",
        ).to(self.device)
        out = self.model(**enc)
        vecs = _mean_pool(out.last_hidden_state, enc["attention_mask"])
        vecs = torch.nn.functional.normalize(vecs, p=2, dim=1)
        return vecs.cpu().float().numpy()


def _collect_response_files(model: str) -> list[Path]:
    safe_model = model.replace("/", "_").replace(":", "_")
    resp_dir = OUTPUTS_DIR / "responses" / safe_model
    if not resp_dir.exists():
        return []
    return sorted(resp_dir.glob("*.json"))


def _parse_response_file(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.warning("Could not parse %s: %s", path, exc)
        return None


def main(args: argparse.Namespace, cfg: dict) -> None:
    encoder_key = args.encoder
    encoder_name = cfg["encoders"].get(encoder_key)
    if encoder_name is None:
        raise ValueError(f"Unknown encoder {encoder_key!r}. Available: {list(cfg['encoders'].keys())}")
    batch_size = args.batch_size if args.batch_size is not None else cfg["embeddings"]["batch_size"]

    response_files = _collect_response_files(args.model)
    if not response_files:
        logger.error("No response files found for model %s. Run run_inference.py first.", args.model)
        sys.exit(1)

    # Filter to files not yet embedded
    pending: list[tuple[Path, dict]] = []
    for rf in response_files:
        rec = _parse_response_file(rf)
        if rec is None:
            continue
        out = embedding_path(
            OUTPUTS_DIR, encoder_key, args.model,
            rec["scenario_id"], rec["grupo_racial_alvo"],
            int(rf.stem.rsplit("_", 1)[-1]),
        )
        if not is_valid_npy(out):
            if out.exists():
                logger.warning("Corrupt/incomplete embedding — will overwrite: %s", out)
            pending.append((rf, rec))

    logger.info(
        "encoder=%s model=%s  total=%d  cached=%d  pending=%d",
        encoder_key, args.model,
        len(response_files), len(response_files) - len(pending), len(pending),
    )
    if not pending:
        print("All embeddings already cached.")
        return

    encoder = Encoder(encoder_key, encoder_name)

    # Batch processing
    for batch_start in tqdm.tqdm(range(0, len(pending), batch_size), desc="Embedding batches"):
        batch = pending[batch_start : batch_start + batch_size]
        texts = [rec["response_text"] for _, rec in batch]
        vecs = encoder.encode(texts)  # (B, D) float32 normalized

        for i, (rf, rec) in enumerate(batch):
            sample_idx = int(rf.stem.rsplit("_", 1)[-1])
            out = embedding_path(
                OUTPUTS_DIR, encoder_key, args.model,
                rec["scenario_id"], rec["grupo_racial_alvo"], sample_idx,
            )
            if is_valid_npy(out):
                continue  # written by a concurrent process
            atomic_write_npy(out, vecs[i])

    logger.info("Done embedding.")
    del encoder
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Embed cached responses with a neutral encoder.")
    parser.add_argument(
        "--encoder", required=True,
        choices=["bge", "e5", "llama"],
        help="Which encoder to use (defined in config.yaml)",
    )
    parser.add_argument("--model", required=True, help="Generative model whose responses to embed")
    parser.add_argument("--batch-size", type=int, default=None)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    cfg = load_config()
    main(args, cfg)
