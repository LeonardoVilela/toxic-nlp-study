#!/usr/bin/env python3
"""Permutation test (WEAT-style) for the STRICT-subset score.

For each permutation:
  1. Within each tuple i, randomly relabel the G×N embeddings across groups.
  2. Recompute sigma2_i under the shuffled assignment.
  3. Recompute mean score across tuples → null distribution sample.

p-value = fraction of null samples ≥ observed score.

Vectorised: all K tuples are shuffled simultaneously per permutation.
10 000 perms on K≈200, G=5, N=5, D=1024 runs in ~1-3 min on CPU.

Usage:
  python pipeline/permutation_test.py --model claude-haiku-4-5 --encoder bge
  python pipeline/permutation_test.py --model claude-haiku-4-5 --encoder bge \\
      --n-permutations 10000 --seed 42
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).parent))

import numpy as np
import tqdm

from _common import (
    OUTPUTS_DIR,
    RACIAL_GROUPS,
    STRICT_CATS,
    embedding_path,
    is_valid_npy,
    load_config,
    load_dataset,
    setup_logging,
)

logger = setup_logging("permutation_test")

G = len(RACIAL_GROUPS)  # 5


def _load_strict_embeddings(
    encoder: str,
    model: str,
    n_samples: int,
    dataset: list[dict],
) -> tuple[np.ndarray, list[str]]:
    """Load all complete STRICT-subset embeddings.

    Returns:
      all_embs  : (K, G, N, D) float32
      scenario_ids: list of K scenario_ids included
    """
    strict = [sc for sc in dataset if sc["categoria"] in STRICT_CATS]
    rows: list[np.ndarray] = []
    kept_ids: list[str] = []

    for sc in strict:
        sid = sc["scenario_id"]
        group_samples: list[np.ndarray] = []
        complete = True
        for group in RACIAL_GROUPS:
            vecs = []
            for s in range(n_samples):
                p = embedding_path(OUTPUTS_DIR, encoder, model, sid, group, s)
                if is_valid_npy(p):
                    vecs.append(np.load(str(p)).astype(np.float32))
            if len(vecs) == 0:
                complete = False
                break
            # Pad or truncate to exactly n_samples (use available)
            group_samples.append(np.stack(vecs))  # (n_found, D)
        if not complete:
            continue
        # Stack groups: (G, n_found, D)
        min_n = min(arr.shape[0] for arr in group_samples)
        stacked = np.stack([arr[:min_n] for arr in group_samples])  # (G, N, D)
        rows.append(stacked)
        kept_ids.append(sid)

    if not rows:
        return np.empty((0,)), []

    # Pad all tuples to same N (use min across all tuples)
    min_n_global = min(r.shape[1] for r in rows)
    padded = np.stack([r[:, :min_n_global, :] for r in rows])  # (K, G, N, D)
    return padded.astype(np.float32), kept_ids


def _observed_score(all_embs: np.ndarray) -> float:
    """all_embs: (K, G, N, D). Returns mean tuple variance."""
    centroids = all_embs.mean(axis=2)          # (K, G, D)
    global_c = centroids.mean(axis=1, keepdims=True)  # (K, 1, D)
    var = ((centroids - global_c) ** 2).sum(axis=2).mean(axis=1)  # (K,)
    return float(var.mean())


def _run_permutations(
    all_embs: np.ndarray,
    n_perms: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """Return null distribution array of shape (n_perms,).

    For each permutation, independently shuffle G×N embeddings within each
    tuple, then recompute the mean tuple variance.
    """
    K, G, N, D = all_embs.shape
    GN = G * N
    combined = all_embs.reshape(K, GN, D)  # (K, GN, D)
    null_scores = np.empty(n_perms, dtype=np.float64)

    for p in tqdm.trange(n_perms, desc="Permutations", unit="perm"):
        # Independent shuffle per tuple: shape (K, GN)
        perm_idx = rng.permuted(
            np.tile(np.arange(GN, dtype=np.int32), (K, 1)),
            axis=1,
        )
        # Gather: combined[k, perm_idx[k], :] for each k
        k_idx = np.arange(K, dtype=np.int32)[:, None]  # (K, 1)
        shuffled = combined[k_idx, perm_idx, :]         # (K, GN, D)
        reshuffled = shuffled.reshape(K, G, N, D)

        centroids = reshuffled.mean(axis=2)             # (K, G, D)
        global_c = centroids.mean(axis=1, keepdims=True)
        var = ((centroids - global_c) ** 2).sum(axis=2).mean(axis=1)  # (K,)
        null_scores[p] = float(var.mean())

    return null_scores


def main(args: argparse.Namespace, cfg: dict) -> None:
    gen = cfg["generation"]
    perm_cfg = cfg["permutation"]
    n_samples = args.n_samples if args.n_samples is not None else gen["n_samples"]
    n_perms = args.n_permutations if args.n_permutations is not None else perm_cfg["n_permutations"]
    seed = args.seed if args.seed is not None else perm_cfg["seed"]

    out_path = args.output
    if out_path is None:
        safe_model = args.model.replace("/", "_").replace(":", "_")
        out_path = str(OUTPUTS_DIR / "scores" / f"{safe_model}_{args.encoder}_permutation.json")

    if Path(out_path).exists():
        try:
            cached = json.loads(Path(out_path).read_text(encoding="utf-8"))
            meta = cached.get("metadata", {})
            if meta.get("n_permutations") == n_perms and meta.get("seed") == seed:
                logger.info(
                    "Permutation cache hit for %s/%s (n_perms=%d seed=%d) — skipping.",
                    args.model, args.encoder, n_perms, seed,
                )
                print(f"Cached: {out_path}  (n_perms={n_perms}, seed={seed})")
                print(f"Observed score : {cached.get('observed_score'):.6f}")
                print(f"p-value        : {cached.get('p_value'):.4f}")
                return
        except Exception as exc:
            logger.warning("Could not read cached permutation output %s: %s", out_path, exc)

    dataset = load_dataset()
    logger.info("Loading embeddings for model=%s encoder=%s", args.model, args.encoder)
    all_embs, kept_ids = _load_strict_embeddings(args.encoder, args.model, n_samples, dataset)

    K = all_embs.shape[0] if all_embs.ndim == 4 else 0
    if K == 0:
        logger.error("No complete tuples found. Run compute_embeddings.py first.")
        sys.exit(1)

    logger.info("Loaded %d complete tuples. Shape: %s", K, all_embs.shape)
    observed = _observed_score(all_embs)
    logger.info("Observed Score_strict = %.6f", observed)

    rng = np.random.default_rng(seed)
    null_dist = _run_permutations(all_embs, n_perms, rng)

    p_value = float((null_dist >= observed).mean())
    ci_low, ci_high = float(np.percentile(null_dist, 2.5)), float(np.percentile(null_dist, 97.5))

    output: dict[str, Any] = {
        "model": args.model,
        "encoder": args.encoder,
        "n_tuples": K,
        "observed_score": observed,
        "p_value": p_value,
        "null_distribution_mean": float(null_dist.mean()),
        "null_distribution_std": float(null_dist.std()),
        "null_ci_95": [ci_low, ci_high],
        "null_distribution": null_dist.tolist(),
        "metadata": {
            "n_permutations": n_perms,
            "seed": seed,
            "computed_at": datetime.now(timezone.utc).isoformat(),
        },
    }

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"Observed score : {observed:.6f}")
    print(f"p-value        : {p_value:.4f}")
    print(f"Null 95% CI    : [{ci_low:.6f}, {ci_high:.6f}]")
    print(f"Output written : {out_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Permutation significance test for Score_strict.")
    parser.add_argument("--model", required=True)
    parser.add_argument("--encoder", required=True, choices=["bge", "e5", "llama"])
    parser.add_argument("--n-permutations", type=int, default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--output", default=None)
    parser.add_argument("--n-samples", type=int, default=None)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    cfg = load_config()
    main(args, cfg)
