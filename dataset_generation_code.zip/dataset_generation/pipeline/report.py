#!/usr/bin/env python3
"""Aggregate scores and produce markdown report + matplotlib figures.

Outputs:
  outputs/reports/summary.md          — tables: Score_strict, p-values, per-category
  outputs/reports/{model}_pairwise.png — heatmap of 5×5 pairwise distance matrix
  outputs/reports/comparison.png       — bar chart comparing Score_strict across models

Labels are in Portuguese.

Usage:
  python pipeline/report.py --models claude-haiku-4-5 gpt-4o-mini --encoder bge
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).parent))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from _common import OUTPUTS_DIR, RACIAL_GROUPS, load_config, setup_logging

logger = setup_logging("report")

REPORTS_DIR = OUTPUTS_DIR / "reports"
SCORES_DIR  = OUTPUTS_DIR / "scores"

# Portuguese labels
GROUP_LABELS_PT = {
    "negro/preto": "Negro/\nPreto",
    "branco": "Branco",
    "pardo": "Pardo",
    "indigena": "Indígena",
    "asiatico/amarelo": "Asiático/\nAmarelo",
}
CAT_LABELS_PT = {
    "associacao_ocupacao": "Assoc. Ocupação",
    "contrafactual_pares": "Contrafactual Pares",
    "saude_e_cuidado": "Saúde e Cuidado",
    "sentimento_e_percepcao": "Sentimento/Percepção",
    "tomada_de_decisao": "Tomada de Decisão",
    "violencia_e_criminalidade": "Violência/Criminalidade",
}


def _load_strict(model: str, encoder: str) -> dict | None:
    safe_model = model.replace("/", "_").replace(":", "_")
    p = OUTPUTS_DIR / "scores" / f"{safe_model}_{encoder}_strict.json"
    if not p.exists():
        logger.warning("Strict scores not found: %s", p)
        return None
    return json.loads(p.read_text(encoding="utf-8"))


def _load_permutation(model: str, encoder: str) -> dict | None:
    safe_model = model.replace("/", "_").replace(":", "_")
    p = OUTPUTS_DIR / "scores" / f"{safe_model}_{encoder}_permutation.json"
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8"))


# ── Within-model helpers ───────────────────────────────────────────────────────

def _get_mean_tuple_r(corr: dict) -> float | None:
    rs = [
        enc["correlation_B_tuple"]["r"]
        for enc in corr.get("correlations_per_encoder", {}).values()
        if enc.get("correlation_B_tuple", {}).get("r") is not None
    ]
    return float(np.mean(rs)) if rs else None


def _load_within_model_entry(alias: str) -> dict | None:
    intr_path  = SCORES_DIR / f"{alias}_intrinsic.json"
    corr_path  = SCORES_DIR / f"{alias}_within_model_correlations.json"
    if not intr_path.exists():
        return None
    intr = json.loads(intr_path.read_text(encoding="utf-8"))
    corr = json.loads(corr_path.read_text(encoding="utf-8")) if corr_path.exists() else {}

    def _strict_score(enc: str) -> float | None:
        p = SCORES_DIR / f"{alias}_{enc}_strict.json"
        if not p.exists():
            return None
        return json.loads(p.read_text(encoding="utf-8")).get("score_strict")

    return {
        "alias":              alias,
        "weat_d":             intr["weat"]["effect_size"],
        "seat_d":             intr["seat"]["effect_size"],
        "sbs":                intr["sbs"]["effect_size"],
        "score_strict_bge":   _strict_score("bge"),
        "score_strict_llama": _strict_score("llama"),
        "pearson_r_cat":      corr.get("correlation_A_combined", {}).get("r"),
        "pearson_r_tuple":    _get_mean_tuple_r(corr),
        "per_scenario_intr":  intr.get("per_scenario_intrinsic_variances", {}),
    }


def _plot_within_model_combined(wm_entries: list[dict]) -> Path | None:
    """Scatter: mean intrinsic variance vs Score_strict(bge), one point per model."""
    x, y, labels = [], [], []
    for e in wm_entries:
        per_scen = e.get("per_scenario_intr", {})
        score_bge = e.get("score_strict_bge")
        if not per_scen or score_bge is None:
            continue
        x.append(float(np.mean(list(per_scen.values()))))
        y.append(score_bge)
        labels.append(e["alias"])
    if not x:
        return None

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(x, y, s=70, color="#DD8452", zorder=3)
    for xi, yi, lab in zip(x, y, labels):
        ax.annotate(lab, (xi, yi), fontsize=9, textcoords="offset points", xytext=(5, 3))
    ax.set_xlabel("Variância intrínseca média (modelo próprio)", fontsize=10)
    ax.set_ylabel("Score_strict extrínseco — encoder BGE", fontsize=10)
    ax.set_title("Validação Intra-Modelo: Intrínseco × Extrínseco", fontsize=11)
    fig.tight_layout()
    out = REPORTS_DIR / "within_model_combined.png"
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved within-model combined plot: %s", out)
    return out


def _fmt_pval(p: float | None) -> str:
    if p is None:
        return "—"
    if p < 0.001:
        return "< 0,001"
    return f"{p:.3f}".replace(".", ",")


def _fmt_score(s: float) -> str:
    return f"{s:.6f}".replace(".", ",")


# ── Heatmap ───────────────────────────────────────────────────────────────────

def _plot_pairwise(model: str, encoder: str, pairwise_data: dict) -> Path:
    matrix = np.array(pairwise_data["matrix"])
    groups = pairwise_data["groups"]
    labels = [GROUP_LABELS_PT.get(g, g) for g in groups]

    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(matrix, cmap="YlOrRd", aspect="auto")
    plt.colorbar(im, ax=ax, label="Distância média entre centroides")

    ax.set_xticks(range(len(groups)))
    ax.set_yticks(range(len(groups)))
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_yticklabels(labels, fontsize=9)

    for i in range(len(groups)):
        for j in range(len(groups)):
            ax.text(
                j, i, f"{matrix[i, j]:.4f}",
                ha="center", va="center", fontsize=8,
                color="white" if matrix[i, j] > matrix.max() * 0.6 else "black",
            )

    ax.set_title(
        f"Matriz de Distâncias entre Grupos\nModelo: {model} | Encoder: {encoder}",
        fontsize=11, pad=12,
    )
    fig.tight_layout()

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    safe_model = model.replace("/", "_").replace(":", "_")
    out = REPORTS_DIR / f"{safe_model}_{encoder}_pairwise.png"
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved pairwise heatmap: %s", out)
    return out


# ── Comparison bar chart ───────────────────────────────────────────────────────

def _plot_comparison(entries: list[dict], encoder: str) -> Path:
    labels = [e["model"] for e in entries]
    scores = [e["score_strict"] for e in entries]
    pvals = [e.get("p_value") for e in entries]

    fig, ax = plt.subplots(figsize=(max(6, len(labels) * 1.6), 5))
    x = np.arange(len(labels))
    bars = ax.bar(x, scores, color="#4C72B0", edgecolor="white", linewidth=0.8)

    for bar, pv in zip(bars, pvals):
        sig = "*" if pv is not None and pv < 0.05 else ""
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + max(scores) * 0.01,
            sig, ha="center", va="bottom", fontsize=14,
        )

    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=20, ha="right", fontsize=9)
    ax.set_ylabel("Score_strict (variância entre grupos)", fontsize=10)
    ax.set_title(
        f"Comparação de Viés Racial entre Modelos\n(Encoder: {encoder}, * p < 0,05)",
        fontsize=11, pad=10,
    )
    ax.set_ylim(0, max(scores) * 1.2 if scores else 1)
    fig.tight_layout()

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    out = REPORTS_DIR / "comparison.png"
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved comparison chart: %s", out)
    return out


# ── Markdown report ────────────────────────────────────────────────────────────

def _build_markdown(
    entries: list[dict],
    encoder: str,
    within_model: list[dict] | None = None,
) -> str:
    lines: list[str] = []
    lines.append("# Relatório de Avaliação de Viés Racial em LLMs\n")
    lines.append(f"**Encoder:** {encoder}  \n")
    lines.append(f"**Subconjunto:** STRICT  \n\n")

    # ── Summary table
    lines.append("## Pontuações Gerais\n")
    header = "| Modelo | Score_strict | Desvio padrão | Tuples completos | p-valor |"
    sep    = "|--------|-------------|----------------|-----------------|---------|"
    lines.append(header)
    lines.append(sep)
    for e in entries:
        lines.append(
            f"| {e['model']} "
            f"| {_fmt_score(e['score_strict'])} "
            f"| {_fmt_score(e.get('score_std', 0.0))} "
            f"| {e['n_tuples_complete']}/{e['n_tuples_strict']} "
            f"| {_fmt_pval(e.get('p_value'))} |"
        )
    lines.append("")

    # ── Per-category tables (one per model)
    lines.append("## Breakdown por Categoria\n")
    all_cats = sorted(
        {cat for e in entries for cat in e.get("per_category", {}).keys()}
    )
    for e in entries:
        lines.append(f"### {e['model']}\n")
        lines.append("| Categoria | Score | Desvio padrão | Tuples |")
        lines.append("|-----------|-------|---------------|--------|")
        for cat in all_cats:
            info = e.get("per_category", {}).get(cat)
            if info:
                cat_pt = CAT_LABELS_PT.get(cat, cat)
                lines.append(
                    f"| {cat_pt} "
                    f"| {_fmt_score(info['score'])} "
                    f"| {_fmt_score(info.get('std', 0.0))} "
                    f"| {info['n_tuples']} |"
                )
        lines.append("")

    # ── Within-model section (only when data exists)
    if within_model:
        lines.append("## Validação Intra-Modelo\n")
        lines.append(
            "| Modelo | WEAT d | SEAT d | SBS "
            "| Score_strict(bge) | Score_strict(llama-1b) "
            "| r (categoria) | r (cenário) |"
        )
        lines.append(
            "|--------|:------:|:------:|:---:"
            "|:-----------------:|:---------------------:"
            "|:-------------:|:-----------:|"
        )
        for wm in within_model:
            def _wfmt(v: object) -> str:
                if v is None:
                    return "—"
                return f"{v:.4f}".replace(".", ",") if isinstance(v, float) else str(v)
            lines.append(
                f"| {wm['alias']} "
                f"| {_wfmt(wm['weat_d'])} "
                f"| {_wfmt(wm['seat_d'])} "
                f"| {_wfmt(wm['sbs'])} "
                f"| {_wfmt(wm['score_strict_bge'])} "
                f"| {_wfmt(wm.get('score_strict_llama'))} "
                f"| {_wfmt(wm['pearson_r_cat'])} "
                f"| {_wfmt(wm['pearson_r_tuple'])} |"
            )
        lines.append("")
        lines.append("![Validação Intra-Modelo](within_model_combined.png)\n")

    lines.append("---\n*Gerado automaticamente pelo pipeline de avaliação.*\n")
    return "\n".join(lines)


# ── Main ──────────────────────────────────────────────────────────────────────

def main(args: argparse.Namespace) -> None:
    entries: list[dict[str, Any]] = []

    for model in args.models:
        strict = _load_strict(model, args.encoder)
        if strict is None:
            continue
        perm = _load_permutation(model, args.encoder)
        entry: dict[str, Any] = {**strict}
        if perm:
            entry["p_value"] = perm["p_value"]
            entry["null_ci_95"] = perm["null_ci_95"]

        entries.append(entry)

        # Pairwise heatmap per model
        if "pairwise_distance_matrix" in strict:
            _plot_pairwise(model, args.encoder, strict["pairwise_distance_matrix"])

    if not entries:
        logger.error("No score files found for the requested models/encoder.")
        sys.exit(1)

    # Comparison chart
    _plot_comparison(entries, args.encoder)

    # Within-model section — scans for any *_intrinsic.json, independent of args.models
    wm_data = [
        e for e in (
            _load_within_model_entry(p.stem.replace("_intrinsic", ""))
            for p in sorted(SCORES_DIR.glob("*_intrinsic.json"))
        )
        if e is not None
    ]
    if wm_data:
        _plot_within_model_combined(wm_data)

    # Markdown report
    md = _build_markdown(entries, args.encoder, wm_data or None)
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    md_path = REPORTS_DIR / "summary.md"
    md_path.write_text(md, encoding="utf-8")
    logger.info("Saved markdown report: %s", md_path)
    print(f"Report: {md_path}")
    print(f"Charts: {REPORTS_DIR}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate aggregate report and figures.")
    parser.add_argument("--models", nargs="+", required=True, help="One or more generative model IDs")
    parser.add_argument("--encoder", required=True, choices=["bge", "e5", "llama"])
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    main(args)
