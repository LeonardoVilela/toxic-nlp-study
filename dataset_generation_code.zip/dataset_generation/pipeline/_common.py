"""Shared utilities: config loading, key management, logging, dataset I/O,
atomic writes, and file validation for crash-safe checkpointing."""
from __future__ import annotations

import json
import logging
import os
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import yaml

ROOT = Path(__file__).parent.parent
DATASET_PATH = ROOT / "frases_vies_geradas.json"
KEYS_FILE = ROOT / "keys.txt"
CONFIG_FILE = Path(__file__).parent / "config.yaml"
OUTPUTS_DIR = ROOT / "outputs"

STRICT_CATS: frozenset[str] = frozenset({
    "associacao_ocupacao",
    "contrafactual_pares",
    "saude_e_cuidado",
    "sentimento_e_percepcao",
    "tomada_de_decisao",
    "violencia_e_criminalidade",
})
IMPLICIT_CATS: frozenset[str] = frozenset({
    "historico_e_merito",
    "estereotipo_implicito",
})
RACIAL_GROUPS: list[str] = [
    "negro/preto",
    "branco",
    "pardo",
    "indigena",
    "asiatico/amarelo",
]


def get_regime(categoria: str) -> str:
    if categoria in STRICT_CATS:
        return "strict"
    if categoria in IMPLICIT_CATS:
        return "implicit_signaling"
    raise ValueError(f"Unknown category: {categoria!r}")


def sanitize_group(group: str) -> str:
    """Make racial group name safe for use in file names."""
    return group.replace("/", "-").replace(" ", "_")


def response_path(outputs_dir: Path, model: str, scenario_id: str, group: str, sample: int) -> Path:
    safe_model = model.replace("/", "_").replace(":", "_")
    safe_group = sanitize_group(group)
    return outputs_dir / "responses" / safe_model / f"{scenario_id}_{safe_group}_{sample}.json"


def embedding_path(outputs_dir: Path, encoder: str, model: str, scenario_id: str, group: str, sample: int) -> Path:
    safe_model = model.replace("/", "_").replace(":", "_")
    safe_group = sanitize_group(group)
    return outputs_dir / "embeddings" / encoder / safe_model / f"{scenario_id}_{safe_group}_{sample}.npy"


def load_keys() -> dict[str, str]:
    keys: dict[str, str] = {}
    if KEYS_FILE.exists():
        for line in KEYS_FILE.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                keys[k.strip()] = v.strip()
    for k in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "GEMINI_API_KEY", "GOOGLE_API_KEY"):
        if k in os.environ:
            keys[k] = os.environ[k]
    # Accept GOOGLE_API_KEY as an alias for GEMINI_API_KEY
    if "GEMINI_API_KEY" not in keys and "GOOGLE_API_KEY" in keys:
        keys["GEMINI_API_KEY"] = keys["GOOGLE_API_KEY"]
    return keys


def load_config() -> dict[str, Any]:
    with open(CONFIG_FILE, encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_dataset() -> list[dict[str, Any]]:
    with open(DATASET_PATH, encoding="utf-8") as f:
        return json.load(f)


# ── Atomic writes ─────────────────────────────────────────────────────────────
# Write to a sibling temp file first, then os.replace() — which is atomic on
# both POSIX and Windows NTFS.  A crash mid-write leaves the .tmp file, not a
# truncated target, so the target is always either absent or fully written.

def atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp.json")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def atomic_write_npy(path: Path, array: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp.npy")
    try:
        os.close(fd)
        np.save(tmp, array)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


# ── File validation ───────────────────────────────────────────────────────────
# Called before treating a cached file as "done".  A zero-byte or truncated
# file from a previous crash is re-queued rather than silently skipped.

def is_valid_json(path: Path) -> bool:
    """Return True iff path exists and contains valid, non-empty JSON."""
    try:
        text = path.read_text(encoding="utf-8")
        obj = json.loads(text)
        return bool(obj)
    except Exception:
        return False


def is_valid_npy(path: Path) -> bool:
    """Return True iff path exists and loads as a finite, non-empty float array."""
    try:
        arr = np.load(str(path))
        return arr.ndim >= 1 and arr.size > 0 and np.isfinite(arr).all()
    except Exception:
        return False


def setup_logging(script_name: str) -> logging.Logger:
    log_dir = OUTPUTS_DIR / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = log_dir / f"{script_name}_{timestamp}.log"

    logger = logging.getLogger(script_name)
    logger.setLevel(logging.DEBUG)
    if logger.handlers:
        return logger

    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)

    sh = logging.StreamHandler()
    sh.setLevel(logging.INFO)
    sh.setFormatter(fmt)

    logger.addHandler(fh)
    logger.addHandler(sh)
    return logger
