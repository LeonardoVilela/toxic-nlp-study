#!/usr/bin/env python3
"""Within-model validation: intrinsic bias in a model's own representations
vs extrinsic Score_strict computed from neutral-encoder embeddings.

Only open-weight models are supported — proprietary APIs do not expose
hidden states.

Stages:
  intrinsic — load the model, encode each STRICT-subset prompt using the
              model's own hidden states, save per-scenario centroid-variance
  compare   — correlate per-scenario intrinsic variances against the
              per-tuple extrinsic variances from compute_scores.py output

Usage:
  python pipeline/within_model_analysis.py --model llama-4-scout --stage intrinsic
  python pipeline/within_model_analysis.py --model llama-4-scout --stage compare
  python pipeline/within_model_analysis.py --model qwen3-8b     --stage intrinsic
  python pipeline/within_model_analysis.py --model qwen3-8b     --stage compare
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).parent))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy import stats
from transformers import AutoModel, AutoTokenizer

from _common import (
    OUTPUTS_DIR,
    RACIAL_GROUPS,
    STRICT_CATS,
    load_dataset,
    setup_logging,
)
from compute_embeddings import _mean_pool  # import, do not duplicate

logger = setup_logging("within_model_analysis")

REPORTS_DIR = OUTPUTS_DIR / "reports"
SCORES_DIR  = OUTPUTS_DIR / "scores"

OPEN_WEIGHT_MODELS: dict[str, str] = {
    "llama-3.1-8b":       "meta-llama/Meta-Llama-3.1-8B-Instruct",
    "qwen3-8b":           "Qwen/Qwen3-8B",
    "qwen3-32b":          "Qwen/Qwen3-32B",
    "openai/gpt-oss-20b": "openai/gpt-oss-20b",
    "llama-4-scout":      "meta-llama/Llama-4-Scout-17B-16E-Instruct",
    "llama-4-maverick":   "meta-llama/Llama-4-Maverick-17B-128E-Instruct",
    "gemma-3-27b":        "google/gemma-3-27b-it",
}

POOLING_STRATEGY: dict[str, str] = {
    "llama-3.1-8b":       "mean",
    "qwen3-8b":           "mean",
    "qwen3-32b":          "mean",
    "openai/gpt-oss-20b": "mean",
    "llama-4-scout":      "mean",
    "llama-4-maverick":   "mean",
    "gemma-3-27b":        "mean",
}

# Aliases that must always load in bnb 4-bit regardless of total VRAM —
# their bf16 footprint exceeds 192 GB (Llama-4 MoE models).
FORCE_4BIT: set[str] = {
    "llama-4-scout",
    "llama-4-maverick",
}

PROPRIETARY_PREFIXES = ("claude", "gpt", "gemini", "o1", "o3", "o4")
COMPARE_ENCODERS = ["bge", "llama"]


# ── Validation ────────────────────────────────────────────────────────────────

def _validate_alias(alias: str) -> None:
    if any(alias.startswith(p) for p in PROPRIETARY_PREFIXES):
        raise ValueError(
            f"within-model analysis requires access to the model's own hidden states.\n"
            f"Model '{alias}' is proprietary and only exposes generated text, not "
            f"representations. Only open-weight models support within-model validation:\n"
            f"{{{', '.join(OPEN_WEIGHT_MODELS)}}}"
        )
    if alias not in OPEN_WEIGHT_MODELS:
        raise ValueError(
            f"Unknown model alias '{alias}'. "
            f"Supported aliases: {{{', '.join(OPEN_WEIGHT_MODELS)}}}"
        )


# ── Pooling ───────────────────────────────────────────────────────────────────

def _last_token_pool(
    token_embeddings: torch.Tensor,
    attention_mask: torch.Tensor,
) -> torch.Tensor:
    # Available for future use if Qwen3-Embedding-8B is added to the suite.
    # NOT dispatched for any model currently in OPEN_WEIGHT_MODELS.
    seq_len = attention_mask.sum(dim=1) - 1
    batch_size = token_embeddings.size(0)
    idx = (
        seq_len.unsqueeze(1)
              .unsqueeze(2)
              .expand(batch_size, 1, token_embeddings.size(2))
    )
    return token_embeddings.gather(1, idx).squeeze(1)


# ── HiddenStateExtractor ──────────────────────────────────────────────────────

class HiddenStateExtractor:
    """Wraps an open-weight causal LM; returns mean-pooled hidden states."""

    def __init__(self, alias: str) -> None:
        _validate_alias(alias)
        self.alias = alias
        self.hf_model_id = OPEN_WEIGHT_MODELS[alias]
        self.pooling = POOLING_STRATEGY[alias]
        device_str = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = torch.device(device_str)
        self.tokenizer = AutoTokenizer.from_pretrained(self.hf_model_id)
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        load_kwargs: dict[str, Any] = {}
        if device_str == "cuda":
            total_vram_gb = sum(
                torch.cuda.get_device_properties(i).total_memory
                for i in range(torch.cuda.device_count())
            ) / (1024 ** 3)
            load_kwargs["device_map"] = "auto"
            if total_vram_gb >= 40 and alias not in FORCE_4BIT:
                load_kwargs["torch_dtype"] = torch.bfloat16
                logger.info(
                    "Loading %s (%s) bf16 device_map=auto across %d GPU(s), %.1f GB total VRAM",
                    alias, self.hf_model_id, torch.cuda.device_count(), total_vram_gb,
                )
            else:
                from transformers import BitsAndBytesConfig
                load_kwargs["quantization_config"] = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_quant_type="nf4",
                    bnb_4bit_compute_dtype=torch.bfloat16,
                    bnb_4bit_use_double_quant=True,
                )
                why = "forced" if alias in FORCE_4BIT else "low-VRAM"
                logger.info(
                    "Loading %s (%s) bnb-4bit NF4 (%s) on %d GPU(s), %.1f GB total VRAM",
                    alias, self.hf_model_id, why,
                    torch.cuda.device_count(), total_vram_gb,
                )
        else:
            logger.info("Loading %s (%s) on cpu fp32", alias, self.hf_model_id)
        self.model = AutoModel.from_pretrained(self.hf_model_id, **load_kwargs)
        if device_str == "cpu":
            self.model = self.model.to(self.device)
        self.model.eval()

    @torch.no_grad()
    def encode(self, texts: list[str], batch_size: int = 8) -> np.ndarray:
        all_vecs: list[np.ndarray] = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            enc = self.tokenizer(
                batch,
                padding=True,
                truncation=True,
                max_length=512,
                return_tensors="pt",
            ).to(self.device)
            out = self.model(**enc)
            if self.pooling == "mean":
                vecs = _mean_pool(out.last_hidden_state, enc["attention_mask"])
            else:
                vecs = _last_token_pool(out.last_hidden_state, enc["attention_mask"])
            vecs = torch.nn.functional.normalize(vecs, p=2, dim=1)
            all_vecs.append(vecs.cpu().float().numpy())
        return np.concatenate(all_vecs, axis=0)


# ── Metric ────────────────────────────────────────────────────────────────────

def _centroid_variance(group_vecs: np.ndarray) -> float:
    """(G, D) → scalar between-group centroid variance. Same formula as Score_strict."""
    mu_bar = group_vecs.mean(axis=0)
    diffs = group_vecs - mu_bar
    return float((diffs ** 2).sum(axis=1).mean())


# ── Per-scenario intrinsic divergence ────────────────────────────────────────

def per_scenario_intrinsic_divergence(
    extractor: HiddenStateExtractor,
    dataset: list[dict],
) -> dict[str, float]:
    """For each STRICT scenario encode all 5 racial-group prompts with the
    model's own hidden states, then compute between-group centroid variance.

    This is the intrinsic counterpart of Score_strict: same formula, applied
    to prompt embeddings from the model itself rather than response embeddings
    from a neutral encoder.

    Returns {scenario_id: intrinsic_variance}.
    """
    strict_scenarios = [sc for sc in dataset if sc["categoria"] in STRICT_CATS]
    result: dict[str, float] = {}
    for sc in strict_scenarios:
        sid = sc["scenario_id"]
        versoes_by_group = {v["grupo_racial_alvo"]: v["frase"] for v in sc["versoes"]}
        missing = [g for g in RACIAL_GROUPS if g not in versoes_by_group]
        if missing:
            logger.warning("Scenario %s missing groups %s — skipping.", sid, missing)
            continue
        prompts = [versoes_by_group[g] for g in RACIAL_GROUPS]
        vecs = extractor.encode(prompts)  # (5, D)
        result[sid] = _centroid_variance(vecs)
    return result


# ── Intrinsic stage ───────────────────────────────────────────────────────────

def stage_intrinsic(alias: str) -> None:
    intrinsic_data_path = (
        Path(__file__).parent.parent
        / "data" / "intrinsic" / "racial_targets_attributes.json"
    )
    if not intrinsic_data_path.exists():
        logger.warning(
            "Intrinsic attribute dataset not found: %s\n"
            "WEAT/SEAT/SBS will be skipped. "
            "Per-scenario intrinsic variances will still be computed.",
            intrinsic_data_path,
        )

    extractor = HiddenStateExtractor(alias)
    dataset = load_dataset()

    logger.info("Computing per-scenario intrinsic variances for %s ...", alias)
    per_scenario_vars = per_scenario_intrinsic_divergence(extractor, dataset)
    del extractor
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    strict_scenarios = [sc for sc in dataset if sc["categoria"] in STRICT_CATS]
    per_cat: dict[str, list[float]] = defaultdict(list)
    for sc in strict_scenarios:
        sid = sc["scenario_id"]
        if sid in per_scenario_vars:
            per_cat[sc["categoria"]].append(per_scenario_vars[sid])
    per_category_scores: dict[str, float] = {
        cat: float(np.mean(vs)) for cat, vs in per_cat.items()
    }

    # WEAT / SEAT / SBS — stubbed pending intrinsic_metrics.py implementation
    weat_result: dict[str, Any] = {"effect_size": None, "p_value": None}
    seat_result: dict[str, Any] = {"effect_size": None, "p_value": None}
    sbs_result:  dict[str, Any] = {"effect_size": None, "p_value": None}

    if intrinsic_data_path.exists():
        try:
            raise NotImplementedError(
                "TODO: implement compute_weat / compute_seat / compute_sbs "
                "in intrinsic_metrics.py"
            )
        except NotImplementedError as exc:
            logger.warning("WEAT/SEAT/SBS not implemented yet: %s", exc)

    output: dict[str, Any] = {
        "model_alias": alias,
        "hf_model_id": OPEN_WEIGHT_MODELS[alias],
        "pooling_strategy": POOLING_STRATEGY[alias],
        "weat": weat_result,
        "seat": seat_result,
        "sbs":  sbs_result,
        "per_scenario_intrinsic_variances": per_scenario_vars,
        "per_category_intrinsic_scores": per_category_scores,
        "metadata": {
            "computed_at": datetime.now(timezone.utc).isoformat(),
            "intrinsic_dataset": (
                str(intrinsic_data_path) if intrinsic_data_path.exists() else None
            ),
            "n_scenarios_computed": len(per_scenario_vars),
            "n_scenarios_total": len(strict_scenarios),
        },
    }

    SCORES_DIR.mkdir(parents=True, exist_ok=True)
    out_path = SCORES_DIR / f"{alias}_intrinsic.json"
    out_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    logger.info("Saved intrinsic scores: %s", out_path)

    mean_var = (
        float(np.mean(list(per_scenario_vars.values()))) if per_scenario_vars else float("nan")
    )
    print(f"Intrinsic scores   : {out_path}")
    print(f"Scenarios computed : {len(per_scenario_vars)}/{len(strict_scenarios)}")
    print(f"Mean intr. variance: {mean_var:.6f}")


# ── Compare stage ─────────────────────────────────────────────────────────────

def _load_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.warning("Could not read %s: %s", path, exc)
        return None


def _pearsonr_safe(
    x: list[float], y: list[float]
) -> tuple[float | None, float | None]:
    if len(x) < 3:
        return None, None
    r, p = stats.pearsonr(x, y)
    return float(r), float(p)


def _scatter_plot(
    x: list[float],
    y: list[float],
    labels: list[str],
    r: float | None,
    p: float | None,
    xlabel: str,
    ylabel: str,
    title: str,
    out_path: Path,
) -> None:
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(x, y, alpha=0.6, s=22, color="#4C72B0")
    for xi, yi, lab in zip(x, y, labels):
        ax.annotate(lab, (xi, yi), fontsize=6, textcoords="offset points", xytext=(3, 2))
    ax.set_xlabel(xlabel, fontsize=10)
    ax.set_ylabel(ylabel, fontsize=10)
    r_str = f"r = {r:.3f}, p = {p:.3g}" if r is not None else "r = —"
    ax.set_title(f"{title}\n{r_str}  (N = {len(x)})", fontsize=10)
    fig.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved plot: %s", out_path)


def stage_compare(alias: str) -> None:
    intrinsic_path = SCORES_DIR / f"{alias}_intrinsic.json"
    intrinsic = _load_json(intrinsic_path)
    if intrinsic is None:
        raise FileNotFoundError(
            f"Intrinsic scores not found: {intrinsic_path}\n"
            f"Run first:  python pipeline/within_model_analysis.py "
            f"--model {alias} --stage intrinsic"
        )

    per_scen_intr: dict[str, float] = intrinsic.get("per_scenario_intrinsic_variances", {})
    per_cat_intr:  dict[str, float] = intrinsic.get("per_category_intrinsic_scores", {})

    correlation_results: dict[str, Any] = {}
    plots_generated: list[Path] = []

    for encoder in COMPARE_ENCODERS:
        strict_path = SCORES_DIR / f"{alias}_{encoder}_strict.json"
        strict = _load_json(strict_path)
        if strict is None:
            logger.warning(
                "Strict scores not found for encoder '%s': %s — skipping.\n"
                "Run: python pipeline/compute_scores.py --model %s --encoder %s",
                encoder, strict_path, alias, encoder,
            )
            continue

        per_tuple_ext: dict[str, float] = strict.get("per_tuple_variances", {})
        per_cat_ext:   dict[str, dict]  = strict.get("per_category", {})

        # Correlation B — tuple-level (N ≈ 221)
        common_b = sorted(set(per_scen_intr) & set(per_tuple_ext))
        x_b = [per_scen_intr[s] for s in common_b]
        y_b = [per_tuple_ext[s] for s in common_b]
        r_b, p_b = _pearsonr_safe(x_b, y_b)
        corr_b: dict[str, Any] = {"r": r_b, "p_value": p_b, "n": len(common_b)}

        if r_b is not None:
            plot_b = REPORTS_DIR / f"{alias}_within_model_tuple_{encoder}.png"
            _scatter_plot(
                x_b, y_b, common_b, r_b, p_b,
                xlabel="Variância intrínseca por cenário (modelo próprio)",
                ylabel=f"Variância extrínseca por cenário (encoder: {encoder})",
                title=f"Correlação por Cenário — {alias} | {encoder}",
                out_path=plot_b,
            )
            plots_generated.append(plot_b)

        # Correlation A — category-level (N = 6 per encoder)
        common_a = sorted(set(per_cat_intr) & set(per_cat_ext))
        x_a = [per_cat_intr[c] for c in common_a]
        y_a = [per_cat_ext[c]["score"] for c in common_a]
        r_a, p_a = _pearsonr_safe(x_a, y_a)
        corr_a: dict[str, Any] = {"r": r_a, "p_value": p_a, "n": len(common_a)}

        correlation_results[encoder] = {
            "correlation_A_category": corr_a,
            "correlation_B_tuple":    corr_b,
        }

    # Combined category scatter across both encoders
    x_all: list[float] = []
    y_all: list[float] = []
    labels_all: list[str] = []
    for encoder in COMPARE_ENCODERS:
        strict = _load_json(SCORES_DIR / f"{alias}_{encoder}_strict.json")
        if strict is None:
            continue
        per_cat_ext = strict.get("per_category", {})
        for c in sorted(set(per_cat_intr) & set(per_cat_ext)):
            x_all.append(per_cat_intr[c])
            y_all.append(per_cat_ext[c]["score"])
            labels_all.append(f"{c[:14]} ({encoder})")

    r_cat, p_cat = _pearsonr_safe(x_all, y_all)
    if x_all:
        plot_cat = REPORTS_DIR / f"{alias}_within_model_category.png"
        _scatter_plot(
            x_all, y_all, labels_all, r_cat, p_cat,
            xlabel="Score intrínseco por categoria (modelo próprio)",
            ylabel="Score_strict extrínseco por categoria",
            title=f"Correlação por Categoria — {alias}",
            out_path=plot_cat,
        )
        plots_generated.append(plot_cat)

    # Markdown report
    def _fmt(v: Any) -> str:
        if v is None:
            return "—"
        if isinstance(v, float):
            return f"{v:.4f}".replace(".", ",")
        return str(v)

    lines: list[str] = [
        f"# Validação Intra-Modelo: {alias}\n",
        f"**Modelo HuggingFace:** `{OPEN_WEIGHT_MODELS[alias]}`  ",
        f"**Pooling:** {POOLING_STRATEGY[alias]}  ",
        f"**Gerado em:** {datetime.now(timezone.utc).isoformat()}  \n",
        "## Métricas Intrínsecas (WEAT/SEAT/SBS)\n",
        "| Métrica | Tamanho de Efeito | p-valor |",
        "|---------|:-----------------:|:-------:|",
        f"| WEAT | {intrinsic['weat']['effect_size'] or '—'} "
        f"| {intrinsic['weat']['p_value'] or '—'} |",
        f"| SEAT | {intrinsic['seat']['effect_size'] or '—'} "
        f"| {intrinsic['seat']['p_value'] or '—'} |",
        f"| SBS  | {intrinsic['sbs']['effect_size'] or '—'}  "
        f"| {intrinsic['sbs']['p_value'] or '—'} |",
        "\n> WEAT/SEAT/SBS pendentes de implementação (`intrinsic_metrics.py`).\n",
        "## Correlações Intrínseco × Extrínseco\n",
        "| Encoder | Corr. A — por categoria (N) | r_A | p_A "
        "| Corr. B — por cenário (N) | r_B | p_B |",
        "|---------|:---------------------------:|:---:|:---:"
        "|:-------------------------:|:---:|:---:|",
    ]
    for encoder, res in correlation_results.items():
        ca = res["correlation_A_category"]
        cb = res["correlation_B_tuple"]
        lines.append(
            f"| {encoder} "
            f"| {ca['n']} | {_fmt(ca['r'])} | {_fmt(ca['p_value'])} "
            f"| {cb['n']} | {_fmt(cb['r'])} | {_fmt(cb['p_value'])} |"
        )

    if r_cat is not None:
        lines += [
            "",
            f"**Correlação A combinada (N={len(x_all)}):** "
            f"r = {r_cat:.3f}, p = {p_cat:.3g}",
        ]

    lines += [
        "",
        "## Interpretação\n",
        "*(Preencher após análise dos resultados.)*\n",
        "---",
        "*Gerado automaticamente pelo pipeline de avaliação.*",
    ]

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    md_path = REPORTS_DIR / f"{alias}_within_model.md"
    md_path.write_text("\n".join(lines), encoding="utf-8")

    # Persist correlation summary as JSON for use by report.py
    corr_summary: dict[str, Any] = {
        "model_alias": alias,
        "correlations_per_encoder": correlation_results,
        "correlation_A_combined": {
            "r": r_cat,
            "p_value": p_cat,
            "n": len(x_all),
        },
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }
    corr_path = SCORES_DIR / f"{alias}_within_model_correlations.json"
    corr_path.write_text(
        json.dumps(corr_summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    logger.info("Saved within-model report: %s", md_path)
    print(f"Within-model report: {md_path}")
    for pl in plots_generated:
        print(f"  Plot: {pl}")


# ── CLI ───────────────────────────────────────────────────────────────────────

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Within-model validation: intrinsic bias vs extrinsic Score_strict.",
    )
    parser.add_argument(
        "--model", required=True,
        help=f"Open-weight model alias. Choices: {{{', '.join(OPEN_WEIGHT_MODELS)}}}",
    )
    parser.add_argument(
        "--stage", required=True, choices=["intrinsic", "compare"],
        help=(
            "intrinsic: encode prompts with hidden states, save per-scenario variances; "
            "compare: correlate intrinsic variances against extrinsic Score_strict"
        ),
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    if args.stage == "intrinsic":
        stage_intrinsic(args.model)
    else:
        stage_compare(args.model)
