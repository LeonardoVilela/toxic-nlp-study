#!/usr/bin/env python3
"""Single entry-point for the full evaluation pipeline.

Runs all steps in order for each model:
  1. run_inference      — query the generative model
  2. compute_embeddings — encode responses with BGE + E5 + Llama-1B (all three)
  3. compute_scores     — STRICT-subset centroid-variance metric (all three encoders)
  4. permutation_test   — significance testing (all three encoders)
  5. analyze_implicit   — implicit-signaling subset metrics
  6. within_model       — intrinsic bias vs extrinsic Score_strict (open-weight only)
  7. report             — combined markdown report + figures (all models together)

Gemini models are placed last — they are slower and rate-limited.

Usage examples:
  # Smoke test — 3 scenarios, 2 samples, Haiku only (< $0.01)
  python pipeline/main.py --models claude-haiku-4-5 --limit 3 --n-samples 2

  # Cheap full run (all encoders, gemini last)
  python pipeline/main.py --models claude-haiku-4-5 gpt-4.1 gemini-3.1-flash-lite-preview

  # Full thesis run — all 6 models, gemini last
  python pipeline/main.py --models claude-sonnet-4-6 claude-haiku-4-5 gpt-5 gpt-4.1 gemini-3.1-pro gemini-3.1-flash-lite-preview

  # Open-weight models (includes within-model validation)
  python pipeline/main.py --models llama-4-scout qwen3-8b

  # Dry-run (free, shows cost estimates)
  python pipeline/main.py --models claude-haiku-4-5 gpt-4.1 gemini-3.1-flash-lite-preview --dry-run

  # Resume — skip steps already done
  python pipeline/main.py --models claude-haiku-4-5 gpt-4.1 gemini-3.1-flash-lite-preview --skip inference
"""
from __future__ import annotations

import argparse
import sys
import time
from argparse import Namespace
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from _common import load_config, setup_logging

logger = setup_logging("main")

ALL_ENCODERS = ["bge", "e5", "llama"]
STEPS = ["inference", "embeddings", "scores", "permutation", "implicit", "within_model", "report"]


# ── Helpers ───────────────────────────────────────────────────────────────────

def _banner(text: str, char: str = "=") -> None:
    width = 62
    print(f"\n{char * width}")
    print(f"  {text}")
    print(f"{char * width}")


def _step_banner(step: str, model: str, i: int, total: int) -> None:
    print(f"\n{'-' * 62}")
    print(f"  [{i}/{total}] {step}  --  {model}")
    print(f"{'-' * 62}")


def _elapsed(start: float) -> str:
    s = int(time.time() - start)
    return f"{s // 60}m {s % 60}s"


# ── Step runners ──────────────────────────────────────────────────────────────

def run_inference(model: str, args: Namespace, cfg: dict) -> None:
    import asyncio
    import run_inference as mod
    step_args = Namespace(
        model=model,
        n_samples=args.n_samples,
        temperature=args.temperature,
        top_p=args.top_p,
        max_tokens=args.max_tokens,
        concurrency=args.concurrency,
        dry_run=args.dry_run,
        limit=args.limit,
    )
    asyncio.run(mod.main(step_args, cfg))


def run_embeddings(model: str, args: Namespace, cfg: dict) -> None:
    import compute_embeddings as mod
    for enc in ALL_ENCODERS:
        print(f"  [encoder: {enc}]")
        try:
            step_args = Namespace(encoder=enc, model=model, batch_size=args.batch_size)
            mod.main(step_args, cfg)
        except SystemExit as exc:
            if exc.code != 0:
                logger.error("embeddings[%s] failed for %s (exit %s)", enc, model, exc.code)
        except Exception as exc:
            logger.error("embeddings[%s] raised for %s: %s", enc, model, exc)


def run_scores(model: str, args: Namespace, cfg: dict) -> None:
    import compute_scores as mod
    for enc in ALL_ENCODERS:
        print(f"  [encoder: {enc}]")
        try:
            step_args = Namespace(model=model, encoder=enc, output=None, n_samples=args.n_samples)
            mod.main(step_args, cfg)
        except SystemExit as exc:
            if exc.code != 0:
                logger.error("scores[%s] failed for %s (exit %s)", enc, model, exc.code)
        except Exception as exc:
            logger.error("scores[%s] raised for %s: %s", enc, model, exc)


def run_permutation(model: str, args: Namespace, cfg: dict) -> None:
    import permutation_test as mod
    for enc in ALL_ENCODERS:
        print(f"  [encoder: {enc}]")
        try:
            step_args = Namespace(
                model=model,
                encoder=enc,
                n_permutations=args.n_permutations,
                seed=args.seed,
                output=None,
                n_samples=args.n_samples,
            )
            mod.main(step_args, cfg)
        except SystemExit as exc:
            if exc.code != 0:
                logger.error("permutation[%s] failed for %s (exit %s)", enc, model, exc.code)
        except Exception as exc:
            logger.error("permutation[%s] raised for %s: %s", enc, model, exc)


def run_implicit(model: str, args: Namespace, cfg: dict) -> None:
    import analyze_implicit as mod
    step_args = Namespace(model=model, n_samples=args.n_samples, output=None)
    mod.main(step_args, cfg)


def run_within_model(model: str, args: Namespace, cfg: dict) -> None:
    import within_model_analysis as mod
    if model not in mod.OPEN_WEIGHT_MODELS:
        print(f"  [skip] {model} is not open-weight — within-model analysis not applicable.")
        return
    mod.stage_intrinsic(model)
    mod.stage_compare(model)


def run_report(completed_models: list[str], args: Namespace) -> None:
    import report as mod
    step_args = Namespace(models=completed_models, encoder=args.encoder)
    mod.main(step_args)


# ── Per-model pipeline ────────────────────────────────────────────────────────

STEP_FN = {
    "inference":   run_inference,
    "embeddings":  run_embeddings,
    "scores":      run_scores,
    "permutation": run_permutation,
    "implicit":    run_implicit,
    "within_model": run_within_model,
}

NON_FATAL_STEPS = {"within_model"}


def run_model(model: str, args: Namespace, cfg: dict, skip: set[str]) -> bool:
    """Run all per-model steps. Returns True on success (within_model failures are non-fatal)."""
    active = [s for s in STEPS if s not in ("report",) and s not in skip]
    total = len(active)

    for i, step in enumerate(active, start=1):
        _step_banner(step, model, i, total)
        step_start = time.time()
        try:
            STEP_FN[step](model, args, cfg)
        except SystemExit as exc:
            if exc.code != 0:
                if step in NON_FATAL_STEPS:
                    print(f"\n[WARN] {step} for {model} failed (exit {exc.code}) — continuing.")
                    logger.warning("Non-fatal step '%s' failed for model '%s'.", step, model)
                else:
                    print(f"\n[FAILED] {step} for {model} (exit {exc.code}) — skipping to next model.")
                    logger.error("Step '%s' failed for model '%s'.", step, model)
                    return False
        except Exception as exc:
            if step in NON_FATAL_STEPS:
                print(f"\n[WARN] {step} for {model}: {exc} — continuing.")
                logger.warning("Non-fatal step '%s' raised for model '%s': %s", step, model, exc)
            else:
                print(f"\n[FAILED] {step} for {model}: {exc}")
                logger.exception("Step '%s' raised an exception for model '%s'.", step, model)
                return False

        print(f"\n[OK] {step} · {model} · {_elapsed(step_start)}")

        if args.dry_run and step == "inference":
            print("\n[dry-run] Skipping remaining steps for this model.")
            return True

    return True


# ── Main ──────────────────────────────────────────────────────────────────────

def main(args: Namespace) -> None:
    cfg = load_config()
    skip = set(args.skip or [])
    models: list[str] = args.models
    pipeline_start = time.time()

    if args.dry_run:
        print("[dry-run mode — no API calls will be made]\n")

    _banner(f"Pipeline starting — {len(models)} model(s)")

    completed: list[str] = []
    for model in models:
        _banner(f"MODEL: {model}", char="#")
        ok = run_model(model, args, cfg, skip)
        if ok and not args.dry_run:
            completed.append(model)

    # Report runs once at the end across all completed models
    if "report" not in skip and completed:
        _banner("REPORT — all models combined", char="#")
        step_start = time.time()
        try:
            run_report(completed, args)
            print(f"\n[OK] report · {_elapsed(step_start)}")
        except Exception as exc:
            print(f"\n[FAILED] report: {exc}")
            logger.exception("Report step failed.")

    _banner(f"Done — {len(completed)}/{len(models)} models · {_elapsed(pipeline_start)}")


def parse_args() -> Namespace:
    parser = argparse.ArgumentParser(
        description="Full racial-bias evaluation pipeline.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # Models
    parser.add_argument(
        "--models", nargs="+", required=True, metavar="MODEL",
        help="One or more model IDs to evaluate in sequence (put slow/rate-limited models last)",
    )
    parser.add_argument(
        "--encoder", default="bge", choices=["bge", "e5", "llama"],
        help="Primary encoder for the final report (default: bge). "
             "All three encoders always run for embeddings/scores/permutation.",
    )

    # Inference
    parser.add_argument("--n-samples", type=int, default=None,
                        help="Samples per prompt (default from config: 5)")
    parser.add_argument("--temperature", type=float, default=None)
    parser.add_argument("--top-p", type=float, default=None)
    parser.add_argument("--max-tokens", type=int, default=None)
    parser.add_argument("--concurrency", type=int, default=None)
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview inference cost per model, then stop")
    parser.add_argument("--limit", type=int, default=None, metavar="K",
                        help="Only process first K scenarios (smoke testing)")

    # Embeddings
    parser.add_argument("--batch-size", type=int, default=None)

    # Permutation test
    parser.add_argument("--n-permutations", type=int, default=None)
    parser.add_argument("--seed", type=int, default=None)

    # Flow control
    parser.add_argument(
        "--skip", nargs="+", choices=STEPS, default=None, metavar="STEP",
        help=f"Steps to skip. Choices: {STEPS}",
    )

    return parser.parse_args()


if __name__ == "__main__":
    main(parse_args())
