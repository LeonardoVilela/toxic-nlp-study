"""Unit tests for permutation_test.py numpy logic."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from permutation_test import _observed_score, _run_permutations


def _make_embeddings(K: int = 10, G: int = 5, N: int = 3, D: int = 16, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    return rng.random((K, G, N, D)).astype(np.float32)


class TestObservedScore:
    def test_identical_groups_gives_zero(self) -> None:
        # If all G groups within each tuple are identical, variance = 0
        v = np.ones((8, 5, 4, 32), dtype=np.float32)
        assert _observed_score(v) == pytest.approx(0.0, abs=1e-6)

    def test_output_is_scalar(self) -> None:
        emb = _make_embeddings()
        score = _observed_score(emb)
        assert isinstance(score, float)
        assert score >= 0.0

    def test_greater_separation_gives_higher_score(self) -> None:
        K, N, D = 10, 3, 16
        # Low separation: groups drawn from same distribution
        rng = np.random.default_rng(7)
        low = rng.random((K, 5, N, D)).astype(np.float32)
        # High separation: each group has a clearly different mean
        high = np.zeros((K, 5, N, D), dtype=np.float32)
        for g in range(5):
            high[:, g, :, :] = g * 10.0
        assert _observed_score(high) > _observed_score(low)

    def test_scale_invariance_of_ranking(self) -> None:
        emb = _make_embeddings(seed=9)
        s1 = _observed_score(emb)
        s2 = _observed_score(emb * 2.0)
        # Scaling by 2 multiplies variance by 4
        assert s2 == pytest.approx(s1 * 4.0, rel=1e-4)


class TestRunPermutations:
    def test_returns_correct_length(self) -> None:
        emb = _make_embeddings(K=5, G=5, N=3, D=8)
        rng = np.random.default_rng(0)
        null = _run_permutations(emb, n_perms=20, rng=rng)
        assert null.shape == (20,)

    def test_null_scores_nonnegative(self) -> None:
        emb = _make_embeddings(K=5, G=5, N=3, D=8)
        rng = np.random.default_rng(1)
        null = _run_permutations(emb, n_perms=30, rng=rng)
        assert (null >= 0).all()

    def test_reproducible_with_same_seed(self) -> None:
        emb = _make_embeddings(K=5, G=5, N=3, D=8)
        null_a = _run_permutations(emb, n_perms=20, rng=np.random.default_rng(42))
        null_b = _run_permutations(emb, n_perms=20, rng=np.random.default_rng(42))
        np.testing.assert_array_equal(null_a, null_b)

    def test_null_distribution_centred_near_observed_when_no_bias(self) -> None:
        # When groups are drawn from the same distribution,
        # the observed score should be close to the median of the null distribution.
        rng_data = np.random.default_rng(55)
        emb = rng_data.random((30, 5, 5, 32)).astype(np.float32)
        observed = _observed_score(emb)
        rng_perm = np.random.default_rng(55)
        null = _run_permutations(emb, n_perms=200, rng=rng_perm)
        # p-value should not be extreme (null hypothesis true)
        p_value = float((null >= observed).mean())
        assert 0.01 < p_value < 0.99, f"Unexpected p-value: {p_value}"

    def test_high_bias_gives_low_p_value(self) -> None:
        # Construct embeddings with artificially strong between-group separation
        K, N, D = 20, 5, 32
        emb = np.zeros((K, 5, N, D), dtype=np.float32)
        for g in range(5):
            emb[:, g, :, :] = float(g) * 100.0  # very far apart
        observed = _observed_score(emb)
        rng = np.random.default_rng(0)
        null = _run_permutations(emb, n_perms=200, rng=rng)
        p_value = float((null >= observed).mean())
        assert p_value < 0.05, f"Expected low p-value for strongly separated groups, got {p_value}"
