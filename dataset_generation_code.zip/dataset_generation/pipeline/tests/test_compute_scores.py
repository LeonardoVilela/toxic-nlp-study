"""Unit tests for the pure-numpy score computations in compute_scores.py."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from compute_scores import _compute_pairwise_distances, _compute_tuple_variance


class TestTupleVariance:
    def test_identical_centroids_gives_zero(self) -> None:
        # If all group centroids are the same, variance must be 0
        centroid = np.array([1.0, 0.0, 0.0])
        group_centroids = np.stack([centroid] * 5)  # (5, 3)
        assert _compute_tuple_variance(group_centroids) == pytest.approx(0.0)

    def test_known_two_group_variance(self) -> None:
        # Two groups, D=1: c0=0, c1=1  → global=0.5, diffs=[0.25,0.25] → var=0.25
        g = np.array([[0.0], [1.0]])
        assert _compute_tuple_variance(g) == pytest.approx(0.25)

    def test_five_groups_symmetrical(self) -> None:
        # 5 groups evenly spaced on a 1-D line
        centroids = np.array([[float(i)] for i in range(5)])  # (5, 1)
        var = _compute_tuple_variance(centroids)
        # global centroid = 2.0; squared diffs = 4,1,0,1,4 → mean = 2.0
        assert var == pytest.approx(2.0)

    def test_output_is_scalar(self) -> None:
        rng = np.random.default_rng(0)
        g = rng.random((5, 64))
        result = _compute_tuple_variance(g)
        assert isinstance(result, float)

    def test_scale_invariance_of_direction(self) -> None:
        # Scaling all centroids by k scales variance by k²
        rng = np.random.default_rng(1)
        g = rng.random((5, 32))
        var1 = _compute_tuple_variance(g)
        var2 = _compute_tuple_variance(g * 3.0)
        assert var2 == pytest.approx(var1 * 9.0, rel=1e-5)


class TestPairwiseDistances:
    def test_diagonal_is_zero(self) -> None:
        rng = np.random.default_rng(2)
        centroids_list = [rng.random((5, 32)).astype(np.float32) for _ in range(10)]
        D = _compute_pairwise_distances(centroids_list)
        np.testing.assert_allclose(np.diag(D), 0.0, atol=1e-6)

    def test_symmetry(self) -> None:
        rng = np.random.default_rng(3)
        centroids_list = [rng.random((5, 16)).astype(np.float32) for _ in range(20)]
        D = _compute_pairwise_distances(centroids_list)
        np.testing.assert_allclose(D, D.T, atol=1e-6)

    def test_shape(self) -> None:
        rng = np.random.default_rng(4)
        centroids_list = [rng.random((5, 8)).astype(np.float32) for _ in range(5)]
        D = _compute_pairwise_distances(centroids_list)
        assert D.shape == (5, 5)

    def test_identical_groups_gives_zero_matrix(self) -> None:
        c = np.ones((5, 16), dtype=np.float32)
        D = _compute_pairwise_distances([c] * 10)
        np.testing.assert_allclose(D, 0.0, atol=1e-6)

    def test_empty_list_gives_zeros(self) -> None:
        D = _compute_pairwise_distances([])
        assert D.shape == (5, 5)
        np.testing.assert_allclose(D, 0.0, atol=1e-6)
