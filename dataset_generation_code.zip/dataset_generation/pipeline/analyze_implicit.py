#!/usr/bin/env python3
"""Analyse the IMPLICIT_SIGNALING subset (42 scenarios).

Metrics computed per group per scenario:
  - Sentiment distribution (positive / neutral / negative) via Portuguese classifier
  - Response length distribution (word count)
  - Refusal rate (fraction of responses matching refusal lexicon)

Does NOT use LLM-as-judge — that is a separate phase.

Usage:
  python pipeline/analyze_implicit.py --model claude-haiku-4-5
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).parent))

from _common import (
    IMPLICIT_CATS,
    OUTPUTS_DIR,
    RACIAL_GROUPS,
    load_config,
    load_dataset,
    response_path,
    sanitize_group,
    setup_logging,
)

logger = setup_logging("analyze_implicit")


# ── Refusal detection ──────────────────────────────────────────────────────────

def _is_refusal(text: str, lexicon: list[str]) -> bool:
    t = text.lower()
    return any(phrase in t for phrase in lexicon)


# ── Sentiment loading (graceful fallback) ─────────────────────────────────────

def _load_sentiment_pipeline(primary: str, fallback: str):
    from transformers import pipeline as hf_pipeline
    for model_name in (primary, fallback):
        try:
            logger.info("Loading sentiment model: %s", model_name)
            pipe = hf_pipeline(
                "sentiment-analysis",
                model=model_name,
                truncation=True,
                max_length=512,
                device=-1,
            )
            logger.info("Loaded %s", model_name)
            return pipe, model_name
        except Exception as exc:
            logger.warning("Could not load %s: %s", model_name, exc)
    logger.warning("No sentiment model available — sentiment scores will be null.")
    return None, None


def _sentiment_label(result: dict | None) -> str | None:
    if result is None:
        return None
    label = result.get("label", "").lower()
    if any(k in label for k in ("pos", "positiv")):
        return "positive"
    if any(k in label for k in ("neg", "negativ")):
        return "negative"
    return "neutral"


# ── Response collection ────────────────────────────────────────────────────────

def _collect_responses(model: str, scenario_id: str, n_samples: int) -> dict[str, list[dict]]:
    """Return group → list of response records."""
    result: dict[str, list[dict]] = defaultdict(list)
    for group in RACIAL_GROUPS:
        for s in range(n_samples):
            p = response_path(OUTPUTS_DIR, model, scenario_id, group, s)
            if p.exists():
                try:
                    rec = json.loads(p.read_text(encoding="utf-8"))
                    result[group].append(rec)
                except Exception as exc:
                    logger.warning("Could not read %s: %s", p, exc)
    return result


# ── Main ──────────────────────────────────────────────────────────────────────

def main(args: argparse.Namespace, cfg: dict) -> None:
    gen = cfg["generation"]
    n_samples = args.n_samples if args.n_samples is not None else gen["n_samples"]
    refusal_lexicon: list[str] = [p.lower() for p in cfg["refusal_lexicon"]]
    sent_cfg = cfg["sentiment"]

    dataset = load_dataset()
    implicit_scenarios = [sc for sc in dataset if sc["categoria"] in IMPLICIT_CATS]
    logger.info("IMPLICIT scenarios: %d", len(implicit_scenarios))

    # Load sentiment model once
    sent_pipe, sent_model_name = _load_sentiment_pipeline(
        sent_cfg["primary"], sent_cfg["fallback"]
    )

    scenarios_out: list[dict[str, Any]] = []

    for sc in implicit_scenarios:
        sid = sc["scenario_id"]
        responses_by_group = _collect_responses(args.model, sid, n_samples)

        groups_out: dict[str, Any] = {}
        for group in RACIAL_GROUPS:
            recs = responses_by_group.get(group, [])
            if not recs:
                groups_out[group] = None
                continue

            texts = [r["response_text"] for r in recs]

            # Refusal rate
            refusal_flags = [_is_refusal(t, refusal_lexicon) for t in texts]
            refusal_rate = sum(refusal_flags) / len(texts)

            # Length distribution
            word_counts = [len(t.split()) for t in texts]

            # Sentiment
            sentiments: list[str | None]
            if sent_pipe is not None:
                raw = sent_pipe(texts)
                sentiments = [_sentiment_label(r) for r in raw]
            else:
                sentiments = [None] * len(texts)

            groups_out[group] = {
                "n_responses": len(texts),
                "refusal_rate": refusal_rate,
                "refusals": int(sum(refusal_flags)),
                "word_count": {
                    "mean": float(sum(word_counts) / len(word_counts)),
                    "min": int(min(word_counts)),
                    "max": int(max(word_counts)),
                    "values": word_counts,
                },
                "sentiment": {
                    "labels": sentiments,
                    "positive": sentiments.count("positive"),
                    "neutral": sentiments.count("neutral"),
                    "negative": sentiments.count("negative"),
                    "null": sentiments.count(None),
                },
            }

        scenarios_out.append({
            "scenario_id": sid,
            "categoria": sc["categoria"],
            "dimensao_vies": sc["dimensao_vies"],
            "groups": groups_out,
        })

    output: dict[str, Any] = {
        "model": args.model,
        "n_scenarios": len(implicit_scenarios),
        "sentiment_model": sent_model_name,
        "refusal_lexicon": refusal_lexicon,
        "scenarios": scenarios_out,
        "metadata": {
            "computed_at": datetime.now(timezone.utc).isoformat(),
            "n_samples_per_group": n_samples,
        },
    }

    safe_model = args.model.replace("/", "_").replace(":", "_")
    out_path = args.output or str(OUTPUTS_DIR / "scores" / f"{safe_model}_implicit.json")
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")

    # Summary
    all_refusal_rates = [
        g["refusal_rate"]
        for sc_out in scenarios_out
        for g in sc_out["groups"].values()
        if g is not None
    ]
    if all_refusal_rates:
        overall_refusal = sum(all_refusal_rates) / len(all_refusal_rates)
        print(f"Overall refusal rate: {overall_refusal:.2%}")
    print(f"Output written: {out_path}")
    logger.info("Done.")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Analyse implicit-signaling subset.")
    parser.add_argument("--model", required=True)
    parser.add_argument("--n-samples", type=int, default=None)
    parser.add_argument("--output", default=None)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    cfg = load_config()
    main(args, cfg)
