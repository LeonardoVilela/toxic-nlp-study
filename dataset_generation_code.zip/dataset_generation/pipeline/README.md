# Pipeline de Avaliação de Viés Racial em LLMs

End-to-end pipeline for generating, embedding, scoring, and visualising racial bias in large language model responses. Built for Brazilian Portuguese benchmark research.

---

## Installation

```bash
# From the dataset_generation/ root
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

pip install -r pipeline/requirements.txt
```

> **CUDA note:** if you have a GPU, PyTorch will use it automatically for embedding. Install the CUDA-enabled torch wheel first if needed: `pip install torch --index-url https://download.pytorch.org/whl/cu121`

### API keys

Create `keys.txt` at the project root (next to `frases_vies_geradas.json`):

```
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
GEMINI_API_KEY=AIza...
```

Keys are also read from environment variables. The file is never logged or printed.

---

## End-to-end example (Claude Haiku + BGE encoder)

```bash
# 0. Dry-run — zero cost, confirms everything is wired up
python pipeline/run_inference.py --model claude-haiku-4-5 --dry-run

# 1. Smoke test: 3 scenarios × 2 samples
python pipeline/run_inference.py --model claude-haiku-4-5 --limit 3 --n-samples 2

# 2. Full inference (263 scenarios × 5 groups × 5 samples = 6 575 calls)
python pipeline/run_inference.py --model claude-haiku-4-5

# 3. Compute embeddings (STRICT + IMPLICIT responses)
python pipeline/compute_embeddings.py --encoder bge --model claude-haiku-4-5

# 4. Score the STRICT subset
python pipeline/compute_scores.py --model claude-haiku-4-5 --encoder bge

# 5. Permutation significance test (10 000 permutations)
python pipeline/permutation_test.py --model claude-haiku-4-5 --encoder bge

# 6. Analyse the IMPLICIT_SIGNALING subset
python pipeline/analyze_implicit.py --model claude-haiku-4-5

# 7. Generate report + figures
python pipeline/report.py --models claude-haiku-4-5 --encoder bge
```

All outputs land in `outputs/` and are **never overwritten**. Every script is fully resumable: rerunning after an interruption costs zero additional API calls.

---

## Script reference

| Script | Input | Output |
|--------|-------|--------|
| `run_inference.py` | `frases_vies_geradas.json` | `outputs/responses/{model}/*.json` |
| `compute_embeddings.py` | response `.json` files | `outputs/embeddings/{encoder}/{model}/*.npy` |
| `compute_scores.py` | `.npy` embeddings | `outputs/scores/{model}_{encoder}_strict.json` |
| `permutation_test.py` | `.npy` embeddings | `outputs/scores/{model}_{encoder}_permutation.json` |
| `analyze_implicit.py` | response `.json` files | `outputs/scores/{model}_implicit.json` |
| `report.py` | score `.json` files | `outputs/reports/summary.md`, `*.png` |

### Common CLI flags

```
--model          Model ID: claude-haiku-4-5 | gpt-4o-mini | gemini-2.0-flash | local/path
--encoder        bge | e5 | llama
--n-samples      Samples per prompt (default: 5)
--limit K        Only process first K scenarios (smoke testing)
--dry-run        Print plan without API calls (run_inference only)
--concurrency    Max concurrent API calls (default: 5)
```

---

## Supported models

| Provider | Example model IDs |
|----------|------------------|
| Anthropic | `claude-haiku-4-5`, `claude-sonnet-4-6`, `claude-opus-4-7` |
| OpenAI | `gpt-4o-mini`, `gpt-4o`, `o3-mini` |
| Google | `gemini-2.0-flash`, `gemini-1.5-pro` |
| Local (transformers) | any HuggingFace model path, e.g. `meta-llama/Llama-4-Scout-17B-16E-Instruct` |

Provider is selected automatically from the model ID prefix.

---

## Cost estimates (N=5, full dataset, 263 scenarios × 5 groups = 1 315 prompts × 5 samples = 6 575 calls)

Approximate costs assuming ~300 input tokens and ~200 output tokens per call:

| Model | Estimated cost |
|-------|---------------|
| `claude-haiku-4-5` | ~$0.79 USD |
| `gpt-4o-mini` | ~$0.15 USD |
| `gemini-2.0-flash` | ~$0.07 USD |
| `claude-sonnet-4-6` | ~$12 USD |
| `gpt-4o` | ~$16 USD |

> **Always run `--dry-run` first.** Stop and verify before spending more than $0.50 (use `--limit 3 --n-samples 2` for a smoke test).

---

## Configuration

Edit `pipeline/config.yaml` to change defaults. All values can be overridden via CLI flags.

Key sections:
- `generation.*` — temperature, top_p, max_tokens, n_samples, concurrency
- `encoders.*` — HuggingFace model names for bge / e5 / llama
- `refusal_lexicon` — Portuguese phrases that count as a refusal
- `sentiment.*` — sentiment classifier model names
- `cost_per_million_tokens.*` — for dry-run cost estimates (not billing)

---

## Running tests

```bash
pytest pipeline/tests/ -v
```

Tests cover the pure-numpy score computation and permutation test logic. No API calls are made.

---

## Troubleshooting

**`No response files found for model X`**
→ Run `run_inference.py` first, or check the model ID spelling. Files are stored under `outputs/responses/{model_id_with_slashes_replaced}`.

**`No complete tuples found`**
→ `compute_scores.py` requires at least one `.npy` file per group per scenario. If only a subset ran, those tuples are reported in `excluded_scenarios`.

**Rate limit errors during inference**
→ Reduce `--concurrency` (try 2 or 1). The script uses exponential backoff up to 6 retries automatically.

**OOM on embedding**
→ Reduce `--batch-size` (try 8 or 4). Embeddings run on CPU if no GPU is detected.

**Sentiment model download fails**
→ `analyze_implicit.py` tries the primary model, then the fallback. If both fail, sentiment columns will be `null`. Run with internet access or pre-download the model with `transformers-cli download`.

**`ModuleNotFoundError: No module named '_common'`**
→ Run scripts from the project root (`dataset_generation/`), not from inside `pipeline/`.

---

## Output structure

```
outputs/
├── responses/
│   └── {model}/
│       └── {scenario_id}_{group}_{sample}.json
├── embeddings/
│   └── {encoder}/
│       └── {model}/
│           └── {scenario_id}_{group}_{sample}.npy
├── scores/
│   ├── {model}_{encoder}_strict.json
│   ├── {model}_{encoder}_permutation.json
│   └── {model}_implicit.json
├── reports/
│   ├── summary.md
│   ├── {model}_{encoder}_pairwise.png
│   └── comparison.png
└── logs/
    └── {script}_{timestamp}.log
```

The pipeline **never deletes or overwrites** cached files. To force a re-run, manually delete the relevant files.
