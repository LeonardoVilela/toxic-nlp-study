#!/usr/bin/env bash
# Bootstrap + full-pipeline launcher for AWS SageMaker g5.48xlarge (8x A10G).
#
# Prereqs on the instance:
#   export HF_TOKEN=hf_xxx
#   keys.txt present at project root with ANTHROPIC_API_KEY, OPENAI_API_KEY, GEMINI_API_KEY
#
# Usage:
#   bash bootstrap_sagemaker.sh

set -euo pipefail

cd "$(dirname "$0")"

# ── Environment checks ────────────────────────────────────────────────────────

if [[ -z "${HF_TOKEN:-}" ]]; then
  echo "ERROR: HF_TOKEN not set. Run: export HF_TOKEN=hf_xxx" >&2
  exit 1
fi

if [[ ! -f keys.txt ]]; then
  echo "ERROR: keys.txt missing. Copy your keys from the local box, or fill in keys.template.txt and rename it." >&2
  exit 1
fi

# HuggingFace libraries auto-read this
export HUGGING_FACE_HUB_TOKEN="$HF_TOKEN"
export HF_HUB_ENABLE_HF_TRANSFER=1   # faster weight downloads

# ── Python env ────────────────────────────────────────────────────────────────

if [[ ! -d .venv ]]; then
  echo "Creating virtualenv..."
  python3 -m venv .venv
fi
source .venv/bin/activate

python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install hf-transfer || true  # best-effort

# ── CUDA sanity ───────────────────────────────────────────────────────────────

python - <<'PY'
import torch
n = torch.cuda.device_count()
assert torch.cuda.is_available(), "CUDA not available"
print(f"CUDA ok: {n} GPU(s)")
for i in range(n):
    p = torch.cuda.get_device_properties(i)
    print(f"  [{i}] {p.name}  {p.total_memory // (1024**3)} GB")
PY

python - <<'PY'
import os
from huggingface_hub import whoami
print("HF user:", whoami(token=os.environ["HF_TOKEN"])["name"])
PY

# ── Full run ──────────────────────────────────────────────────────────────────
# API models first (cached — instant). Open-weight last (heaviest VRAM).
# Qwen3-32B is heaviest; put it last so we do not block lighter models on a slow load.

python pipeline/main.py --models \
  claude-haiku-4-5 \
  gpt-4.1 \
  gemini-3.1-flash-lite-preview \
  llama-3.1-8b \
  qwen3-8b \
  gemma-3-27b \
  openai/gpt-oss-20b \
  qwen3-32b \
  llama-4-scout \
  llama-4-maverick
