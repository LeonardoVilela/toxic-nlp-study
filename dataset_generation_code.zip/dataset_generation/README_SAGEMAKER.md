# SageMaker g5.48xlarge run — dataset_generation

Target: **ml.g5.48xlarge** (8× NVIDIA A10G, 192 GB VRAM total, 768 GB RAM, Linux).

## 1. Upload and unzip

Upload `dataset_generation_sagemaker.zip` to the instance and extract:

```bash
unzip dataset_generation_sagemaker.zip
cd dataset_generation
```

## 2. Set credentials

```bash
export HF_TOKEN=hf_xxx   # HuggingFace token with access to Llama-3.1 and gpt-oss
```

Put your API keys in `keys.txt` (same format as your local box):

```
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
GEMINI_API_KEY=...
```

The API-model responses are already cached under `outputs/responses/` and will NOT be regenerated, but the keys are still validated at provider-import time.

## 3. Run

```bash
bash bootstrap_sagemaker.sh
```

That script:
1. Creates `.venv`, installs `requirements.txt`.
2. Verifies CUDA (8 GPUs), verifies HF token.
3. Runs `pipeline/main.py` for all 6 models.

Cached stages are skipped automatically:
- Claude / GPT / Gemini inference → already cached.
- Embeddings / scores / permutations already computed → skipped.

## 4. Monitor

```bash
tail -f outputs/logs/run_inference_*.log
tail -f outputs/logs/main_*.log
nvidia-smi -l 2                      # live GPU utilization
```

## 5. Expected runtime (fresh run of open-weight models, **vLLM backend**)

Inference goes through vLLM with continuous batching + PagedAttention, so
throughput is ~5-20× higher than stock `transformers.generate()`.

| Model                | Precision  | TP  | Approx. inference time |
|----------------------|------------|-----|------------------------|
| `llama-3.1-8b`       | bf16       | 1   | 5–10 min               |
| `qwen3-8b`           | bf16       | 1   | 5–10 min               |
| `openai/gpt-oss-20b` | bf16       | 2   | 10–20 min              |
| `gemma-3-27b`        | bf16       | 4   | 15–30 min              |
| `qwen3-32b`          | bf16       | 4   | 20–40 min              |
| `llama-4-scout`      | 4-bit bnb  | 4   | 1–2 h                  |
| `llama-4-maverick`   | 4-bit bnb  | 8   | **6–12 h**             |

**Maverick caveat**: 400B params at 4-bit ≈ 200 GB, barely fits in the
192 GB total VRAM of g5.48xlarge. vLLM may OOM or fall back to CPU offload.
If it does, either (a) upgrade to p4d.24xlarge (320 GB) or p5.48xlarge
(640 GB), or (b) remove `llama-4-maverick` from `bootstrap_sagemaker.sh`.

Within-model (hidden-state) analysis runs AFTER inference for each model.
vLLM memory is explicitly released before transformers loads the same
model for extraction.

Total without Maverick: **≈ 3–5 h end to end** (was 12–24 h on transformers).

## 6. Fetching results

Download from `outputs/scores/` and `outputs/reports/`. The final markdown
report is at `outputs/reports/summary_<timestamp>.md`.

## Notes

- **Inference backend**: vLLM. Loaded per model with a per-alias
  `tensor_parallel_size` set in `pipeline/providers/local_provider.py` (the
  `TP_SIZE` dict). Change there if you switch instance types.
- **Hidden-state extraction**: plain transformers (vLLM doesn't expose
  `last_hidden_state`). The code auto-selects bf16 + `device_map="auto"` on
  big boxes, and 4-bit bnb for the Llama-4 MoE models where bf16 won't fit.
- `generation.batch_size: 256` in config.yaml: vLLM's continuous batcher is
  happiest with thousands of pending requests. The chunk size only affects
  progress-bar granularity.
- Interruption is safe — every stage caches per-file and resumes cleanly.
- First load of each vLLM model takes 2-5 min (weight download, compilation
  of CUDA graphs). Subsequent runs reuse the HF cache.
